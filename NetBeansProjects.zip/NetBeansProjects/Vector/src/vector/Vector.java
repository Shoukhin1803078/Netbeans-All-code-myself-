

package vector;


public class Vector {

    
    public static void main(String[] args) {
        Vector a=new Vector ();
      a.add(5);
      a.add(6);
      a.add(7);
      a.add(8);
      a.add("shoukhin");
      a.add("alamin");
      a.add("tokder");
      a.add("shoukhin");
      a.add("abutaher");
      a.add("Mustakim");
      a.add("shoukhin");
      System.out.println(a);


System.out.println(a.contains("shoukhin"));
System.out.println(a.get(6));
System.out.println(a.indexOf("shoukhin"));
System.out.println(a.lastIndexOf("shoukhin"));


a.remove("Mustakim");
System.out.println(a);

a.setElementAt("azimon", 7);
System.out.println(a);

a.insertElementAt("azimon", 9);
System.out.println(a);


System.out.println(a.capacity());


 //a.clear();
 //System.out.println(a);
 //System.out.println(a.isEmpty());
    }
    
}
