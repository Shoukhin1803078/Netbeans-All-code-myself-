
package javaapplication13;

import java.util.Vector;


public class ScienceFair{
	
	void print_result(Vector<Integer>v)
	{
		System.out.println(v);
	}
}
