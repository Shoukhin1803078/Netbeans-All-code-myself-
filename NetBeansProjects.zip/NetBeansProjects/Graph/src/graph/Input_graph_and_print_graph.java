
package graph;

import java.util.Scanner;
import java.util.Vector;

public class Input_graph_and_print_graph{

	public static void main(String[] args){
		Scanner ob=new Scanner(System.in);

		int node=ob.nextInt();
		Vector<Integer> v[]=new Vector[node+1];
		int edge=ob.nextInt();
		for(int i=1;i<v.length;i++){
			v[i]=new Vector();
		}
		for(int i=1;i<=edge;i++){
			int x=ob.nextInt();
			int y=ob.nextInt();
			v[x].add(y);
			v[y].add(x);
		}
		for(int i=1;i<=node;i++){
			System.out.println("list"+(i+1)+"="+v[i]);
		}
	}

}
/*
4 6 
1 3 
1 4
1 2 
2 4 
3 4 
2 3 
*/
