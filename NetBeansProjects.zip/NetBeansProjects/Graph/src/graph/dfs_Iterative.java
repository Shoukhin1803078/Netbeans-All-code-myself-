package graph;

import java.util.Scanner;
import java.util.Stack;
import java.util.Vector;

public class dfs_Iterative{

	public static void main(String[] args){
		Scanner ob=new Scanner(System.in);
		int node=ob.nextInt();
		Vector<Integer> v[]=new Vector[node+1];
		int edge=ob.nextInt();
		for(int i=1;i<v.length;i++){
			v[i]=new Vector();
		}
		for(int i=0;i<edge;i++){
			int x=ob.nextInt();
			int y=ob.nextInt();
			v[x].add(y);
			v[y].add(x);
		}
		for(int i=1;i<=node;i++){
			System.out.println("list"+i+"="+v[i]);
		}
		int visited[]=new int[node+1];
		int purple[]=new int[node+1];
		Stack<Integer> s=new Stack();
		s.push(1);
		//System.out.println(s);
		while(!s.isEmpty()){
			int x=s.pop();
			System.out.println(x);
			visited[x]=1;
			for(int i=0;i<v[x].size();i++){
				int y=v[x].get(i);
				if(visited[y]==0){
					s.push(y);
				}
			}
		           //System.out.println(s);
		}

	}
}

/*
4 6 
1 3 
1 4
1 2 
2 4 
3 4 
2 3 
 */

/*
sir er example in khata
6 6 
1 3
1 2
2 4
4 3 
4 5 
5 6 
*/