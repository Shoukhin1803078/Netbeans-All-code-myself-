/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graph;

/**
 *
 * @author User
 */
public class NewClass1{

	static void convert_to_adjacency(matrix){
		start=0
		res= []
    lst= []
    n=len(matrix)

		fori in range(n){
			
		}
		:
        res.append(lst*n)
		whilestart<n:
        y=matrix[start]
		fori in range(len(y)){
			
		}
		:
            ify[i]==1:
                res[start].append(i)
		start+=1
		return res
	}

	public static void main(String[] args){

		int matrix[][]={{0,1,1,1,0,1,1,0,0},
		{1,0,0,1,0,0,1,1,0},
		{1,0,0,1,0,0,0,0,0},
		{1,1,1,0,1,0,0,0,0},
		{0,0,0,1,0,1,0,0,1},
		{1,0,0,0,1,0,0,0,1},
		{1,1,0,0,0,0,0,0,0},
		{0,1,0,0,0,0,0,0,0},
		{0,0,0,0,1,1,0,0,0}};
		System.out.print(convert_to_adjacency(matrix));
	}

}
