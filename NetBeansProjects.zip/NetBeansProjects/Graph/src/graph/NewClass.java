/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graph;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;
import java.util.Vector;

/**
 *
 * @author User
 */
public class NewClass{
	
static int visited[];
static Vector <Integer> v[];
	public static void main(String[] args){
		Scanner ob=new Scanner(System.in);
		System.out.print("Enter the number of vertices : ");
		int node=ob.nextInt();
		
		visited=new int[node+1];
		v=new Vector[node+1];
		
		
		int a[][]=new int[node+1][node+1];
		
		System.out.println("\n Enter graph data in  Matrix Form: ");
		for(int i=1;i<=node;i++){
			for(int j=1;j<=node;j++){
				a[i][j]=ob.nextInt();
			}
		}

		//Vector<Integer> v[]=new Vector[node];
		for(int i=0;i<=node;i++){
			v[i]=new Vector();
		}

		for(int i=1;i<=node;i++){
			for(int j=1;j<=node;j++){
				if(a[i][j]==1){
					v[i].add(j);
				}
			}
		}

		//int edge=ob.nextInt();
		//for(int i=1;i<v.length;i++){
		//	v[i]=new Vector();
		//}
		//for(int i=0;i<)
		//for(int i=0;i<edge;i++){
		//	int x=ob.nextInt();
		//	int y=ob.nextInt();
		//	v[x].add(y);
		//	v[y].add(x);
		//}
		//for(int i=0;i<=node;i++){
			//System.out.println("list"+i+"="+v[i]);
		//}
		/*int visited[]=new int[node+1];
		int purple[]=new int[node+1];
		Stack<Integer> s=new Stack();
		s.push(1);
		//System.out.println(s);
		while(!s.isEmpty()){
			int x=s.pop();
			System.out.println(x);
			visited[x]=1;
			for(int i=0;i<v[x].size();i++){
				int y=v[x].get(i);
				if(visited[y]==0){
					s.push(y);
				}
			}
		           //System.out.println(s);
		}*/
		System.out.println("Enter the starting vertex :");
		int start=ob.nextInt();
		bfs(start);

	}
	static void bfs(int src) {
		Queue<Integer> q=new LinkedList();
		q.add(src);
		visited[src]=1;
		System.out.println("The node which are reachable are :");
		Iterator it=q.iterator();
		while (it.hasNext()) {
			int curr=q.poll();
			for (int child : v[curr]) {
				if (visited[child]==0) {
					visited[child]=1;
					System.out.print(child+" ");
					q.add(child);
				}
			}
		}
		System.out.println();
	}
}
/*
4
0 1 1 1 
1 0 1 0
1 1 0 0
1 0 0 0
*/
