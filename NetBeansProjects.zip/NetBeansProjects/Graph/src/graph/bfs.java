/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graph;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class bfs {
	
	static ArrayList<Integer> a[];
	static int visited[];
	static int dis[];

	public static void main(String[] args) {
		Scanner ob=new Scanner(System.in);
		int n=ob.nextInt();
		a=new ArrayList[n];
		visited=new int[n+1];
		//dis=new int[n+1];
		int m=ob.nextInt();
		for(int i=0;i<n;i++)
		{
		a[i]=new ArrayList();
		}
		for (int i=0; i<m; i++) {
			int u=ob.nextInt();
			int v=ob.nextInt();
			a[u].add(v);
			a[v].add(u);
		}
		for(int i=0;i<a.length;i++){System.out.println("list"+i+" "+a[i]);}
		
		bfs(1);
	}

	static void bfs(int src) {
		Queue<Integer> q=new LinkedList();
		q.add(src);
		visited[src]=1;
		System.out.println(src);
		//dis[src]=0;
		Iterator it=q.iterator();
		while (it.hasNext()) {
			int curr=q.poll();
			for (int child : a[curr]) {
				if (visited[child]==0) {
					visited[child]=1;
					System.out.println(child);
					q.add(child);
				//	dis[child]=dis[curr]+1;
				}
			}
		}
	}
}
/*
4 4 
0 1
0 2
1 2
0 3
*/