/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myproject;

import java.awt.Container;
import javax.swing.JFrame;

/**
 *
 * @author User
 */
public class KisuGuruttopurnoKoth extends JFrame
{
KisuGuruttopurnoKoth()
{
this.setVisible(true);
this.setBounds(100,200,300,300);
Container c=new Container();
c=this.getContentPane();
c.setLayout(null);

}
	public static void main(String[] args) {
		KisuGuruttopurnoKoth k=new KisuGuruttopurnoKoth();
		
		
	}
}