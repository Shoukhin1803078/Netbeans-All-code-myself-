
package file;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Formatter;
public class NewClass {
    public  static  void main(String [] args ) 
    {
    String s="sdfdjklsh";
    File ob=new File ("student");
    ob.mkdir();
    try {
    File ob1=new File ("C:/Users/User/Documents/NetBeansProjects/File/student/teacher .txt ");
    ob1.createNewFile();
    
	
    File ob4=new File ("T");
    ob4.mkdir();
    File ob3=new File ("C:/Users/User/Documents/NetBeansProjects/File/T/teacher .txt");
    ob3.createNewFile();
    //Formatter ob2=new Formatter ("C:/Users/User/Documents/NetBeansProjects/File/student/teacher .txt ");
    
    //ob2.format(s);
    //ob2.close();
    
    FileWriter ob2=new FileWriter ("C:/Users/User/Documents/NetBeansProjects/File/student/teacher .txt ");
     BufferedWriter bw = new BufferedWriter(ob2);
     bw.write("al amin");
     bw.write("shou");
     bw.close();
    }
    catch(Exception e)
    {
    System .out.println(e);
    }
    
    }   
}
