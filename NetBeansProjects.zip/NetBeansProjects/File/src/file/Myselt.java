package File;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Scanner;

public class Myselt {

	public static void main(String[] args) {
		/* try {
         byte bWrite [] = {11,21,3,40,5};
         OutputStream os = new FileOutputStream("test.txt");
         for(int x = 0; x < bWrite.length ; x++) {
            os.write( bWrite[x] );   // writes the bytes
         }
         os.close();
     
         InputStream is = new FileInputStream("test.txt");
         int size = is.available();

         for(int i = 0; i < size; i++) {
            System.out.print((char)is.read() + "  ");
         }
         is.close();
      } catch (IOException e) {
         System.out.print("Exception");
      }	*/
		try {
			File f = new File("Test1.txt");
			f.createNewFile();
			FileWriter fw = new FileWriter("C:\\Users\\User\\Documents\\NetBeansProjects\\File\\Test1.txt");
			//FileWriter fw = new FileWriter("C:\\Users\\User\\Documents\\NetBeansProjects\\File\\Test1.txt", true);
			int x = 123;
			String s =Integer.toString(x);
			fw.write(s);
			fw.close();
//File theke data read kora

			Scanner ob = new Scanner(f);
			while (ob.hasNext()) {
				String s1=ob.nextLine();
				int i=Integer.valueOf(s1);
				System.out.println(i);
			}
			ob.close();
		} catch (Exception e) {
			System.out.println("Find some problem");
		}
	}

}
