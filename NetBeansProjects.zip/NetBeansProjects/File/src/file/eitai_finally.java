/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package file;

import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class eitai_finally{
	public static void main(String[] args){
		try {
			File f = new File("shoukhin.txt");
			Scanner obf = new Scanner(f);
			int n=obf.nextInt();
			System.out.println(n);
			int a[]=new int[n];
			for(int i=0;i<n;i++)
			{
				a[i]=obf.nextInt();
				System.out.println(a[i]);
				
			}
			
		//	while (ob.hasNext()) {
				//String s1=ob.nextLine();
				//int i=Integer.valueOf(s1);
				//System.out.println(i);
			//}
			//obf.close();
		} catch (Exception e) {
			System.out.println("Find some problem");
		}
	}
}
