/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sazzad;

import java.util.Scanner;


public class Sazzad{

	void bike(){
		Bike ob1=new Bike();
		ob1.putModel();
		ob1.putGear();
		ob1.puttorque();
		ob1.putmileage();
		ob1.putspeed();
		ob1.getModel();
		ob1.getMileage();
		ob1.gettorque();
		ob1.getGear();


	}

	void car(){
		Car ob2=new Car();
		ob2.putModel();
		ob2.putGear();
		ob2.puttorque();
		ob2.putmileage();
		ob2.putspeed();
		ob2.getModel();
		ob2.getMileage();
		ob2.gettorque();
		ob2.getGear();
		
	}

	void bus(){
		Bus ob3=new Bus();
		ob3.putModel();
		ob3.putGear();
		ob3.puttorque();
		ob3.putmileage();
		ob3.putspeed();
		ob3.getModel();
		ob3.getMileage();
		ob3.gettorque();
		ob3.getGear();
	
	}

	public static void main(String[] args){
		Sazzad ob=new Sazzad();
		Scanner sc=new Scanner(System.in);
		System.out.println(" What you want ? \n if you want to create  bike object press 1 \n if you want to create  car  object press 2\n if you want to create  bus object press 3");

		int x=sc.nextInt();
		if(x==1){
			ob.bike();
		}else if(x==2){
			ob.car();
		}else{
			ob.bus();
		}
//ob.

	}

}
