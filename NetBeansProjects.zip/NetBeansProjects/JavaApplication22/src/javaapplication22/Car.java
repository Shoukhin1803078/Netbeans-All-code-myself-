/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sazzad;

import java.util.Scanner;


public class Car{
	String model;
	int gear;
	double torque;
	int speed;
	int mileage;
	void putModel(){
		System.out.println("input gear:");
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		this.model=s;
	}

	void putGear(){
		System.out.println("input gear:");
		Scanner sc=new Scanner(System.in);
		int g=sc.nextInt();
		this.gear=g;
	}

	void puttorque(){
		System.out.println("input torque:");
		Scanner sc=new Scanner(System.in);
		int t=sc.nextInt();
		
		this.torque=t;
	}

	void putmileage(){
		System.out.println("input mileage:");
		Scanner sc=new Scanner(System.in);
		int m=sc.nextInt();
		this.mileage=m;
	}

	void putspeed(){
		System.out.println("input speed:");
		Scanner sc=new Scanner(System.in);
		int s=sc.nextInt();
		this.speed=s;
	}
	void getMileage(){
		System.out.println("Car mileage: "+mileage);
	}
	void getGear()
	{
		System.out.println("Car model: "+gear);
	}
	void getModel()
	{
		System.out.println("Car model: "+model);
	}
	void gettorque()
	{
		System.out.println("Car torque: "+torque);
	}
	void getspeed()
	{
	System.out.println("Car speed: "+speed);
	}
}