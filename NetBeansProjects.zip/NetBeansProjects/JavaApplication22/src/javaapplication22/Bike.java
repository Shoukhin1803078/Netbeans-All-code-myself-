
//package sazzad;

import java.util.Scanner;

public class Bike{

	String model;
	int gear;
	double torque;
	int speed;
	int mileage;

	void putModel(){
		System.out.println("input Model:");
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		this.model=s;
	}

	void putGear(){
		System.out.println("input gear:");
		Scanner sc=new Scanner(System.in);
		int g=sc.nextInt();
		this.gear=g;
	}

	void puttorque(){
		System.out.println("input torque:");
		Scanner sc=new Scanner(System.in);
		int t=sc.nextInt();
		
		this.torque=t;
	}

	void putmileage(){
		System.out.println("input mileage:");
		Scanner sc=new Scanner(System.in);
		int m=sc.nextInt();
		this.mileage=m;
	}

	void putspeed(){
		System.out.println("input speed:");
		Scanner sc=new Scanner(System.in);
		int s=sc.nextInt();
		this.speed=s;
	}

	void getMileage(){
		System.out.println("bike mileage: "+mileage);
	}

	void getGear(){
		System.out.println("bike model: "+gear);
	}

	void getModel(){
		System.out.println("bike model: "+model);
	}

	void gettorque(){
		System.out.println("bike torque: "+torque);
	}

	void getspeed(){
		System.out.println("bike speed: "+speed);
	}
}
