/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication22;

import java.util.Scanner;


public class Student{
	int id;
	double cgpa;
	int course;
	String n;
	void get()
	{
	Scanner ob=new Scanner(System.in);
		System.out.println("enter id :");
	int x=ob.nextInt();
	this.id=x;
	System.out.println("enter name :");
	
	String s=ob.next();
	this.n=s;
	System.out.println("enter gpa :");
	double c=ob.nextDouble();
	this.cgpa=c;

	}
	void put()
	{
	
		System.out.println("Id :"+id);
		
	System.out.println("name :"+n);
	
	System.out.println("gpa :"+cgpa);
	

	}
	
}
