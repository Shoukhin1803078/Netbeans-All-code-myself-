package numbertheory;

import java.util.Scanner;
import java.util.Vector;

public class isprime {

	public static void main(String[] args) {
		int n=1000000;
		Scanner ob=new Scanner(System.in);
		
		boolean a[]=new boolean[n+5];
		for (int i=0; i<a.length; i++) {
			a[i]=true;
		}
		//System.out.println(a[3]);
		for (int i=2; i<=Math.sqrt(n); i++) {
			if (a[i]==true) {
				for (int j=i*i; j<=n; j+=i) {
					a[j]=false;
				}
			}
		}
		Vector<Integer> v=new Vector();
		for (int i=2; i<=n; i++) {
			if (a[i]==true) {
				v.add(i);
			}
		}
		System.out.println("Enter n : ");
		int n1=ob.nextInt();
		if(v.contains(n1)){System.out.println("prime number");}
		else{System.out.println("composite number");}
	}
}
