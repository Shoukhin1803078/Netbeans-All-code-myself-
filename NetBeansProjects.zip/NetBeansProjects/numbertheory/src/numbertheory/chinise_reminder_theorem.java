
package numbertheory;
import java.util.Scanner;
public class chinise_reminder_theorem {
	
	static int x;//count korar jonno niyesi
	static int q[]=new int[100];
	static int s[]=new int[100];
	static int t[]=new int[100];

	static int extended_eucledean(int a, int b) {
		int r=a%b;
		q[1]=a/b;
		x++;
		while (r!=0) {
			a=b;
			b=r;
			//System.out.println("a="+a+"  b= "+b);
			q[x+1]=a/b;
			r=a%b;
			x++;
		}
		s[0]=1;
		s[1]=0;
		t[0]=0;
		t[1]=1;
		for (int j=2; j<x+1; j++) {
			s[j]=s[j-2]-q[j-1]*s[j-1];
			t[j]=t[j-2]-q[j-1]*t[j-1];
		}
		return s[x];
	}

	public static void main(String[] args) {
		//System.out.println(14453%3465);
		Scanner ob=new Scanner(System.in);
		System.out.println("Enter system size:");
		int n=ob.nextInt();
		int aa[]=new int[n];
		int mm[]=new int[n];
		for(int i=0;i<n;i++)
		{
			System.out.print("enter a"+(i+1)+"=");
			aa[i]=ob.nextInt();
			System.out.print("enter m"+(i+1)+"=");
			mm[i]=ob.nextInt();
		}
		int M[]=new int[n];
		int m=1;
		for(int i=0;i<n;i++)
		{
		m*=mm[i];
		}
		for(int i=0;i<n;i++)
		{
		M[i]=m/mm[i];
			System.out.println(M[i]);
		}
		int y[]=new int[n];
		for(int i=0;i<n;i++)
		{
			y[i]=extended_eucledean(M[i],mm[i]);
			//System.out.println(y[i]);
			for(int j=0;j<s.length;j++)
			{
			s[j]=0;
			t[j]=0;
			q[j]=0;
			}
	                      x=0;			  
		}
		//ans ber korbo 
		int sum=0;
		for(int i=0;i<n;i++)
		{
		sum+=(aa[i]*M[i]*y[i]);
		}
		System.out.println("x="+sum+"mod"+m);
	}
}