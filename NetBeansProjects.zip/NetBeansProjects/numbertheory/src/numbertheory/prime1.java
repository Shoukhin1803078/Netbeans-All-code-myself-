package numbertheory;

import java.util.Scanner;

public class prime1 {


}
