package numbertheory;

import java.util.Collections;
import java.util.Scanner;
import java.util.Vector;

public class NewClass {

    public static void main(String[] args) {
        Scanner ob=new Scanner(System.in);
        boolean a[]=new boolean[1000000];
        Vector v=new Vector();
        int n=(int) Math.sqrt(200000);
        for (int i=0; i<n; i++) {
            a[i]=true;
        }

        for (int i=3; i<=Math.sqrt(n); i+=2) {
            if (a[i]==true) {
                for (int j=i*i; j<=n; j=j+i) {
                    a[j]=false;
                }
            }
        }
        for (int i=2; i<=n; i+=2) {
            a[i]=false;
        }
        v.add(2);
        for (int i=3; i<=n; i++) {
            if (a[i]==true) {
                v.add(i);
            }
        }
       
        Vector v1=new Vector ();
        for(int i=0;i<v.size();i++)
        {
        for(int j=0;j<v.size();j++)
        {
            int x=(int )v.get(i)*(int )v.get(j);
         if(v1.contains(x)){continue;}
         else
         {v1.add(x);}
        }
        }
        Collections.sort(v1);
        v1.remove(0);
        for(int i=0;i<v1.size();i++)
        {
            System.out.println(v1.get(i));
        }
          int T=ob.nextInt();
        for (int t=1; t<=T; t++) {
        int x=ob.nextInt();
         if (x<=25) {
                System.out.println("NO");
            }
         else
         {
         int k=0;
        for(int i=0;i<v1.size();i++)
        {
        if((int )v.get(i)>(x/2)){
        k=i;break;
        }
        }
        k=k-1;
             System.out.println(k);
         }
        
            
        }
    }
}
