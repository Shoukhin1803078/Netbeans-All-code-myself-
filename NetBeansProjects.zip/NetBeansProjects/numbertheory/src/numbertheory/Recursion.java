package numbertheory;
import java.util.Scanner;
public class Recursion {
    static int f(int x,int y,int count)
    {
    if(x>y){return count;}
    count++;
    x=x*3;
    y=y*2;
    return f(x,y,count);
    }
    public static void main(String[] args) {
        Scanner ob=new Scanner(System.in);
     int x=ob.nextInt();
     int y=ob.nextInt();
     int count=0;
        System.out.println(f(x,y,count));
    }
}