package numbertheory;
import java.util.Scanner;
public class Seive {
    static int n;
    static boolean a[] = new boolean[100000];

    public static void display() {
        for (int i = 2; i <= n; i++) {
            if (a[i] == false) {
                System.out.println(i + "Prime");
            } else {
                System.out.println(i + "Not");
            }
        }
    }

    public static void seive() {
        for (int i = 0; i <= n; i++) {
            a[i] = false;
        }
        for (int i = 2; i < Math.sqrt(n); i++) {
            if (a[i] == false) {
                for (int j = i * i; j <= n; j = j + i) {
                    a[j] = true;
                }
            }
        }
    }
    
    public static void main(String[] args) {
        Scanner ob = new Scanner(System.in);
        n = ob.nextInt();
        seive();
        display();
    }
}