package numbertheory;
import java.util.ArrayList;
import java.util.Scanner;
public class decimalTobinary {
    public static void main(String[] args) {
        int n,base;
        ArrayList v=new ArrayList();
        Scanner ob=new Scanner(System.in);
        System.out.println("enter number:");
        n=ob.nextInt();
        System.out.println("enter base:");
        base=ob.nextInt();
        //binary te porinoto korar code
       // for(int i=a;i!=0;i=i/2)
        //{
          //v.add(i & (2-1));   // i % 2
        //}
        for(int i=n;i!=0;i=i/base)
        {
        v.add(i%base);
        }
        for(int i=v.size()-1;i>=0;i--)
        {
            System.out.print(v.get(i));
        }
    }
}