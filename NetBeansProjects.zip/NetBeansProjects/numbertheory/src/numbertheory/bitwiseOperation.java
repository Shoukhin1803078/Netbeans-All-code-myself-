package numbertheory;
public class bitwiseOperation {
    public static void main(String[] args) {
        int a=32;
        int b=32;
        System.out.println(a&(b-1));
    }
}