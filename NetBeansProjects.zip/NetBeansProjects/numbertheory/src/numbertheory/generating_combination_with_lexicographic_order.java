
package numbertheory;

import java.util.Scanner;

public class generating_combination_with_lexicographic_order {
	public static void main(String[] args) {
		Scanner ob=new Scanner(System.in);
		System.out.println("enter setsize n=");
		int n=ob.nextInt();
	
		System.out.println("enter r=");
		int r=ob.nextInt();
		
		System.out.println("enter combination (string)=");
		String s=ob.next();
		int a[]=new int[r+1];
		for(int k=0;k<s.length();k++){a[k+1]=s.charAt(k)-'0';}
		int i=r;
		while(a[i]==n-r+i){i--;}
		//System.out.println(i);
		int x=a[i];
		a[i]=a[i]+1;
		//System.out.println(a[i]);
		for(int j=i+1;j<=r;j++)
		{
		a[j]=x+j-i+1;
		}
		System.out.println("next combination is:");
		for(int k=1;k<a.length;k++)
		{
			System.out.print(a[k]);
		}
	}
}