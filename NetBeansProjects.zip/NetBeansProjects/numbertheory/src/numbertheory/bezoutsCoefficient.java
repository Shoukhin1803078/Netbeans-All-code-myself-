/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package numbertheory;

import java.util.Scanner;

public class bezoutsCoefficient {

	public static void solve(long a, long b) {
		long x=0, y=1, lastx=1, lasty=0, temp;
		while (b!=0) {
			long q=a/b;
			long r=a%b;

			a=b;
			b=r;

			temp=x;
			x=lastx-q*x;
			lastx=temp;

			temp=y;
			y=lasty-q*y;
			lasty=temp;
		}
		System.out.println("Roots  s : "+lastx+" t :"+lasty);
	}

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		
		System.out.println("Enter a b of sa + tm = gcd(a, m)\n");
		long a=scan.nextLong();
		long b=scan.nextLong();
		solve(a, b);
	}
}
