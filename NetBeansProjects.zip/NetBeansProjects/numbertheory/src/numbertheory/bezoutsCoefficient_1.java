/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package numbertheory;

import java.util.Scanner;

public class bezoutsCoefficient {
static int x;//count korar jonno niyesi
	static int arr[]=new int[100];
	static int s[]=new int[100];
	static int t[]=new int[100];

	static int eucledean(int a, int b) {
		int r=a%b;
		arr[1]=a/b;
		x++;
		while (r!=0) {
			a=b;
			b=r;
			//System.out.println("a="+a+"  b= "+b);
			arr[x+1]=a/b;
			r=a%b;
			x++;
		}
		return b;
	}

	static void extended() {
		s[0]=1;
		s[1]=0;
		t[0]=0;
		t[1]=1;
		for (int j=2; j<x+1; j++) {
			s[j]=s[j-2]-arr[j-1]*s[j-1];
			t[j]=t[j-2]-arr[j-1]*t[j-1];
		}
		System.out.println("s="+s[x]+" t="+t[x]);
	}

	public static void main(String[] args) {
		Scanner ob=new Scanner(System.in);
		System.out.println("enter a=");
		int a=ob.nextInt();
		System.out.println("enter m=");
		int m=ob.nextInt();
		System.out.println("gcd("+a+","+m+")="+eucledean(a, m));
		extended();
		//for(int i=0;i<x+1;i++){System.out.println(arr[i]);}

	}
}
