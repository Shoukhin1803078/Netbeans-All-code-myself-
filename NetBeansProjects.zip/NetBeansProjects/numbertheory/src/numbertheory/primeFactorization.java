package numbertheory;

import java.util.Vector;

public class primeFactorization {

	static boolean a[]=new boolean[10000];//all set 0 
	static Vector<Integer> v=new Vector();

	public static void main(String[] args) {
		int n=8;
		for (int i=2; i<Math.sqrt(n); i++) {
			if (a[i]==false) {
				for (int j=i*i; j<=n; j=j+i) {
					a[j]=true;
				}
			}
		}
		for (int i=2; i<=n; i++) {
			if (a[i]==false) {
				v.add(i);
			}
		}
		/*	for (int i=0; i<v.size(); i++) {
			System.out.println(v.get(i));
		}
		 */
		Vector list=new Vector();
		for (int i=0;  v.get(i)<=Math.sqrt(n); i++) {//for(int i=0;n!=1;i++){}
			if ((n%( v.get(i)))==0) {
				while (n%( v.get(i))==0) {
					n/= v.get(i);
					list.add(v.get(i));
				}
			}
		}
		for (int i=0; i<list.size(); i++) {
			System.out.println(list.get(i));
		}

	}
}
