package numbertheory;

import java.util.Scanner;

public class prime {

    public static void main(String[] args) {
        int n, m;
        Scanner ob = new Scanner(System.in);
        n = ob.nextInt();
        m = ob.nextInt();
        int k = 0;
        for (int j = n; j <= m; j++) {
            for (int i = 2; i <= j-1; i++) {
                if (j % i == 0) {
                    k = 1;
                    break;
                }
            }
            if (k == 0) {
                System.out.println(j);
            } 
            k = 0;
        }
    }
}
