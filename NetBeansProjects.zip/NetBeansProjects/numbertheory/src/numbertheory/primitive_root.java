
package numbertheory;

import java.util.Scanner;

public class primitive_root {
	public static void main(String[] args) {
		  Scanner ob=new Scanner(System.in);
		
		System.out.println("enter b:");
		int b=ob.nextInt();
		//System.out.println((111*111)%645);
		System.out.println("Enter n:");
		int n=ob.nextInt();
		//Vector<Integer>v=new Vector();
		String s="";
		while (n!=0) {
			s=s+(n%2);
			//v.add(n%2);
			n=n/2;
		}
		//System.out.println(s);
		int x=1;
		System.out.println("enter m:");
		int m=ob.nextInt();
		int p=b%m;
		for (int i=0; i<s.length(); i++) {
			if (s.charAt(i)=='1') {
				x=(x*p)%m;
			}
			p=(p*p)%m;
		}
		System.out.println(x);
		  
		  
		  for(int i=1;i<19;i++)
		  {
		   
		  }
	}
}
