package numbertheory;
import java.util.Scanner;
public class extented_eucledean {
	static int gcd_extendend(int a,int b ,int x,int y)
	{
	if(b==0){
		y=0;
		x=1;
	return a;
	}
	int x1=1;int y1=1;
	int gcd=gcd_extendend(b,a%b,x1,y1);
	x=y1;
	y=x1-(a/b)*y1;
	return gcd;
	}
	static int mod_inverse(int a,int m)
	{
		int res=0;
	int x=1;int y=1;
	int gcd=gcd_extendend(a,m,x,y);
		System.out.println(x);
	if(gcd==1)
	{
	 res=((x%m)+m)%m;
		//return res;
	}
	else{
		System.out.println("a and b er modular inverse exist kore na");
	}
	return res;
	}
	public static void main(String[] args) {
		Scanner ob=new Scanner(System.in); 
		int a=ob.nextInt();
		int b=ob.nextInt();
		//int x=1,y=1;
		//System.out.println(gcd_extendend(a,b,x,y));
		System.out.println(mod_inverse(a,b));
		
	}
}