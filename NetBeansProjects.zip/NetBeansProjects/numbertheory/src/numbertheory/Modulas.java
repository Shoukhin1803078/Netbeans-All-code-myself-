package numbertheory;
import java.util.Scanner;
public class Modulas {
	public static void main(String[] args) {
		Scanner ob=new Scanner(System.in);
		long a=ob.nextInt();
		long b=ob.nextInt();
		long c=ob.nextInt();
		long m=ob.nextInt();
		System.out.println(((a%m)*(b%m)*(c%m))%m);
	}
}
