package numbertheory;

import java.util.ArrayList;
import java.util.Scanner;

public class grabAportionOfAstring {

    static int A;
    static ArrayList a = new ArrayList();

    static void binaryConvert(int n) {
        for (int i = n; i != 0; i = i / 2) {
            a.add(i %2);
        }
        System.out.println("binary form:");
        for (int i = a.size() - 1; i >= 0; i--) {
            System.out.print(a.get(i));
        }
    }

    public static void main(String[] shoukhin) {

        Scanner ob = new Scanner(System.in);
        System.out.println("Enter a number : 19981");
        A = 19881;
        binaryConvert(A); //A=0000 0000 0000 0000 0100 1101 1010 1001
        int X = 0;                 //X=0000 0000 0000 0000 0000 0000 0000 0000
        System.out.println("\nkoto theke koto th bit kete nite cao:"); // Suppose 3th theke 9th porjonto bit kete nite casssi
        int m, n;
        m = ob.nextInt();
        n = ob.nextInt();
        for (int i = 0; i < (n - m); i++) {
            X = (X << 1) | 1;
        }                        //X=00 0000 0000 0000 0000 0000 111111
        X = X << 3;           //X=00 0000 0000 0000 0000 0 111111000

        X = X & A;           //X=00 0000 0000 0000 0000 0 1101 1010 1 000    3th theke 9th bit kete neoa hoyese
        X = X >> 3;           //X=00 0000 0000 0000 0000 0 1101 1010 1            obosese peye gelam
    
        System.out.println("3th theke 9th bit gulor decimal form:"+X);
      
        

    }
}
