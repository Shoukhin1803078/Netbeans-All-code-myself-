package project;

import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Project1 extends JFrame {

	Project1() {

		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(550, 200, 700, 400);
		fitness();

	}

	public void fitness() {
		Container ob1 = new Container();
		ob1 = this.getContentPane();
		ob1.setLayout(null);
		ob1.setBackground(Color.green);

		Font ob50 = new Font("Rockwell Extra Bold", Font.BOLD, 20);
		JLabel ob3 = new JLabel();
		ob3.setText("Student  Health &  Fitness");
		ob3.setOpaque(true);
		ob3.setBackground(Color.black);
		ob3.setForeground(Color.RED);
		ob3.setBounds(160, 40, 350, 50);
		ob3.setFont(ob50);
		ob1.add(ob3);

		Cursor ob40 = new Cursor(Cursor.HAND_CURSOR);

		Font ob51 = new Font("arial", Font.BOLD, 20);
		JButton ob4 = new JButton();
		ob4.setText("Log in another Account");
		//ob4.setBackground(Color.blue);
		ob4.setForeground(Color.RED);
		ob4.setBounds(160, 100, 350, 50);
		ob4.setFont(ob50);
		ob4.setCursor(ob40);
		ob1.add(ob4);

		ob4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Project ob100 = new Project();
				ob100.setVisible(true);
			}
		});

		Font ob52 = new Font("arial", Font.BOLD, 20);
		JButton ob5 = new JButton();
		ob5.setText("Create a new Account");
		//ob4.setBackground(Color.blue);
		ob5.setForeground(Color.RED);
		ob5.setBounds(160, 160, 350, 50);
		ob5.setFont(ob50);
		ob5.setCursor(ob40);
		ob1.add(ob5);

		ob5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Project2 ob100 = new Project2();
				ob100.setVisible(true);
			}
		});

	}

	public static void main(String[] args) {
		Project1 ob = new Project1();

	}

}
