package project;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class MainProject extends JFrame {
private Container ob1;
	MainProject() {
		
		ob1=new Container();
		ob1 = this.getContentPane();
		ob1.setBackground(Color.GREEN);
		ob1.setLayout(null);

		Font f1 = new Font("arial", Font.BOLD, 18);
		JButton jbt1 = new JButton();
		jbt1.setText("Create New Account ");
		jbt1.setForeground(Color.BLUE);
		jbt1.setBounds(100, 200, 300, 50);
		jbt1.setFont(f1);
		ob1.add(jbt1);

		JButton jbt2 = new JButton();
		jbt2.setText("enter previous Account ");
		jbt2.setBounds(100, 300, 300, 50);
		ob1.add(jbt2);

		jbt1.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				
				Project2 p2=new Project2();
				p2.setVisible(true);
				dispose();
				
				/*String s = JOptionPane.showInputDialog(null, "Enter how many student:", "DATA", JOptionPane.INFORMATION_MESSAGE);
				int n;
				n = Integer.parseInt(s);

				student stu[] = new student[n];//student class er array
				for (int i = 0; i < n; i++) {
					stu[i] = new student();
				}
				for (int i = 0; i < n; i++) {
					System.out.println("Input " + i + "th student data");
					stu[i].set();
					System.out.println("File is sucessfully saved");
					try {
						File f1 = new File("shoukhin.txt");
						f1.createNewFile();
						FileWriter fw = new FileWriter("C:/Users/HP/Documents/NetBeansProjects/Project/shoukhin.txt", true);
						BufferedWriter bf = new BufferedWriter(fw);
						bf.write(i + "th student data:\n");
						bf.write(stu[i].name);
						bf.write(stu[i].rollstring);
						bf.write(12);
						bf.write("\n\n");
						bf.close();
					} catch (IOException ex) {
					}
				}
				 */
				
				
			}

		});
	}

	public static void main(String[] args) {
		MainProject ob = new MainProject();

		ob.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ob.setVisible(true);
		ob.setBounds(300, 50, 600, 700);
		//Main project er sathe project 2 er connection ase

	}
}
