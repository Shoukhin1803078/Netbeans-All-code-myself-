package project;

import java.io.BufferedReader;
import java.io.FileReader;

public class ProjectDemo1 {
    public static void main(String[] args)
    {   
        ProjectDemo c[]=new ProjectDemo[1];
       for (int i=0;i<c.length;i++)
       {
        c[i]=new ProjectDemo();
        c[i].get();
       }
        try
        {
          FileReader fr=new FileReader ("shoukhin.txt");
          BufferedReader ob=new BufferedReader (fr);
          
          while(ob)
          {
          String s=ob.readLine();
          System.out.println(s);
          }
              
          fr.close();
        }
        catch(Exception ex)
                {
                //System.out .println(ex);
                }
    }
   
}