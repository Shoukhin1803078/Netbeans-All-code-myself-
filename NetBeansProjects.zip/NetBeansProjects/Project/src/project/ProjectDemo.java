package project;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;
public class ProjectDemo {
     String name ;
    int roll;
    float height ;
    float weight ;
    ProjectDemo()
    {
        
        System.out.println("Input Nameroll height and weight :");
        Scanner ob=new Scanner(System.in);
        this.name=ob.nextLine();
        roll=ob.nextInt();
        this.height=ob.nextFloat();
        this.weight=ob.nextFloat();
        File f=new File("AlAmin");
        f.mkdir();
        System.out.println("Your data is successfully saved in file ");
        try
        {
                FileWriter fw=new FileWriter ("shoukhin.txt",true);
                BufferedWriter bf=new BufferedWriter(fw);
                
                bf.write(name+"\n");
                bf.write(roll+"\n");
                
                String s1=new String ();
                s1=Float.toString(height);
                bf.write(s1+"\n");
               
                String s2=new String ();
                s2=Float.toString(weight);
                bf.write(s2+"\n");

               
                bf.close();
                
        }
        catch(Exception E){
            System.out.println(E);
        }
    }   
    void get()
    {
        System.out.println("Name :"+name);
        System.out.println("Roll:"+roll);
        System.out.println("Height:"+height);
        System.out.println("Weight:"+weight);
    }
}