package project;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class student {
        String name;
        int roll;
        String rollstring;
        
     void set ()
    {
       // System.out.println("enter name:");
        //Scanner ob=new Scanner (System.in);
      // name= ob.nextLine();
       // System.out.println("enter roll:");
        //roll=ob.nextInt();
    JOptionPane.showMessageDialog(null,"Enter student data:","Student Data",JOptionPane.INFORMATION_MESSAGE);
    name=JOptionPane.showInputDialog(null,"Enter name :","Student Data",JOptionPane.INFORMATION_MESSAGE);
    
    //String r=JOptionPane.showInputDialog(null,"Enter roll :","Student Data",JOptionPane.INFORMATION_MESSAGE);
    //roll=Integer.parseInt(r);
  
        rollstring=JOptionPane.showInputDialog(null,"Enter roll :","Student Data",JOptionPane.INFORMATION_MESSAGE);
    }
     void get()
     {
     JOptionPane.showMessageDialog(null,"Name="+name+"\nroll="+roll,"Student Data",JOptionPane.INFORMATION_MESSAGE);
     }
}