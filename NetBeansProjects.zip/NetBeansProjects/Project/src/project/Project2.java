package project;

import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Formatter;
import java.util.logging.Handler;
import java.util.logging.LogRecord;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Project2 extends JFrame {

	private Container ob1;
	private JTextField ob3, ob5, ob10, ob11;
	private JButton ob6, ob7, ob12, ob13, ob14, ob15, ob16, ob17, ob18;
	private JLabel ob2, ob4, ob8, ob9;

	Project2() {
		fitness2();
	}

	public void fitness2() {
		try {
			File ob99 = new File("shoukhin");
			ob99.mkdir();
			File ob98 = new File("C:/Users/User/Documents/NetBeansProjects/Project/shoukhin/profile.txt");
			ob98.createNewFile();
			FileWriter ob97 = new FileWriter("C:/Users/User/Documents/NetBeansProjects/Project/shoukhin/profile.txt");
			BufferedWriter bw = new BufferedWriter(ob97);
			bw.write("student health and Fitness :\n");
			bw.close();
		} catch (Exception e) {
			System.out.println(e);
		}

		ob1 = new Container();
		ob1 = this.getContentPane();
		ob1.setLayout(null);
		ob1.setBackground(Color.green);

		Font ob50 = new Font("arial", Font.BOLD, 16);

		ob2 = new JLabel();
		ob2.setOpaque(true);
		ob2.setBackground(Color.green);
		ob2.setBounds(10, 10, 130, 50);
		ob2.setText("Enter name:");
		ob2.setFont(ob50);
		ob1.add(ob2);

		ob3 = new JTextField();
		ob3.setBounds(170, 10, 200, 50);
		ob3.setFont(ob50);
		ob1.add(ob3);

		ob4 = new JLabel();
		ob4.setOpaque(true);
		ob4.setBackground(Color.green);
		ob4.setBounds(10, 70, 130, 50);
		ob4.setText("Enter Age   :");
		ob4.setFont(ob50);
		ob1.add(ob4);

		ob5 = new JTextField();
		ob5.setBounds(170, 70, 200, 50);
		ob5.setFont(ob50);
		ob1.add(ob5);

		Cursor ob60 = new Cursor(Cursor.HAND_CURSOR);
		ob6 = new JButton();               //Saving Button
		ob6.setText(" Saving ");
		ob6.setBounds(170, 300, 200, 50);
		ob6.setFont(ob50);
		ob6.setCursor(ob60);
		ob1.add(ob6);

		ob8 = new JLabel();
		ob8.setOpaque(true);
		ob8.setBackground(Color.green);
		ob8.setBounds(10, 130, 160, 50);
		ob8.setText("Enter your weight:");
		ob8.setFont(ob50);
		ob1.add(ob8);

		ob9 = new JLabel();
		ob9.setOpaque(true);
		ob9.setBackground(Color.green);
		ob9.setBounds(10, 190, 160, 50);
		ob9.setText("Enter your height:");
		ob9.setFont(ob50);
		ob1.add(ob9);

		ob10 = new JTextField();
		ob10.setBounds(170, 130, 200, 50);
		ob10.setFont(ob50);
		ob1.add(ob10);

		ob11 = new JTextField();
		ob11.setBounds(170, 190, 200, 50);
		ob11.setFont(ob50);
		ob1.add(ob11);

		ob7 = new JButton();
		ob7.setText("clear");
		ob7.setBounds(450, 10, 80, 50);
		ob7.setFont(ob50);
		ob1.add(ob7);

		ob7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ob3.setText("");
			}
		});

		ob12 = new JButton();
		ob12.setText("ok");
		ob12.setBounds(380, 10, 60, 50);
		ob12.setFont(ob50);
		ob1.add(ob12);

		ob12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String s1 = ob3.getText();
				System.out.println("Name=" + s1);
				try {
					FileWriter ob96 = new FileWriter("C:/Users/User/Documents/NetBeansProjects/Project/shoukhin/profile.txt", true);
					BufferedWriter bw = new BufferedWriter(ob96);
					bw.write("Name = " + s1 + "\n");
					bw.close();
				} catch (Exception ex) {
					System.out.println(ex);
				}
				JOptionPane.showMessageDialog(null, "Ok Input next field", "Student health  and Fitness", JOptionPane.INFORMATION_MESSAGE);
			}
		});

		ob13 = new JButton();                     //second
		ob13.setText("clear");
		ob13.setBounds(450, 70, 80, 50);
		ob13.setFont(ob50);
		ob1.add(ob13);

		ob13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ob5.setText("");
			}
		});

		ob14 = new JButton();                 //second
		ob14.setText("ok");
		ob14.setBounds(380, 70, 60, 50);
		ob14.setFont(ob50);
		ob1.add(ob14);

		ob14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String age = ob5.getText();
				System.out.println("age=" + age);
				try {
					FileWriter ob95 = new FileWriter("C:/Users/User/Documents/NetBeansProjects/Project/shoukhin/profile.txt", true);
					BufferedWriter bw = new BufferedWriter(ob95);
					bw.write("age = " + age + "\n");
					bw.close();
				} catch (Exception ex) {
					System.out.println(ex);
				}
				JOptionPane.showMessageDialog(null, "Ok Input next field", "Student health  and Fitness", JOptionPane.INFORMATION_MESSAGE);
			}
		});

		ob15 = new JButton();               //third
		ob15.setText("ok");
		ob15.setBounds(380, 130, 60, 50);
		ob15.setFont(ob50);
		ob1.add(ob15);

		ob15.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String weight = ob10.getText();
				System.out.println("Weight=" + weight);
				try {
					FileWriter ob97 = new FileWriter("C:/Users/User/Documents/NetBeansProjects/Project/shoukhin/profile.txt", true);
					BufferedWriter bw = new BufferedWriter(ob97);
					bw.write("Weight= " + weight + "\n");
					bw.close();
				} catch (Exception ex) {
					System.out.println(ex);
				}
				JOptionPane.showMessageDialog(null, "Ok Input next field", "Student health  and Fitness", JOptionPane.INFORMATION_MESSAGE);
			}
		});

		ob16 = new JButton();             //third
		ob16.setText("clear");
		ob16.setBounds(450, 130, 80, 50);
		ob16.setFont(ob50);
		ob1.add(ob16);

		ob16.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ob10.setText("");
			}
		});

		ob17 = new JButton();                //fourth
		ob17.setText("clear");
		ob17.setBounds(450, 190, 80, 50);
		ob17.setFont(ob50);
		ob1.add(ob17);

		ob17.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ob11.setText("");
			}
		});

		ob18 = new JButton();               //fourth
		ob18.setText("ok");
		ob18.setBounds(380, 190, 60, 50);
		ob18.setFont(ob50);
		ob1.add(ob18);

		ob18.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String height = ob11.getText();
				System.out.println("Height=" + height);
				try {
					FileWriter ob97 = new FileWriter("C:/Users/User/Documents/NetBeansProjects/Project/shoukhin/profile.txt", true);
					BufferedWriter bw = new BufferedWriter(ob97);
					bw.write("Height = " + height + "\n");
					bw.close();
				} catch (Exception ex) {
					System.out.println(ex);
				}

				JOptionPane.showMessageDialog(null, "Ok Input next field", "Student health  and Fitness", JOptionPane.INFORMATION_MESSAGE);
			}
		});

		Handler ob = new Handler();      //Keboard e enter button press korle akan theke kaj korbe 
		ob3.addActionListener(ob);
		ob5.addActionListener(ob);
		ob10.addActionListener(ob);
		ob11.addActionListener(ob);

		ob6.addActionListener(ob);

	}

	class Handler implements ActionListener {

		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == ob3) {
				String s1 = ob3.getText();
				System.out.println("Name=" + s1);
				try {
					FileWriter ob96 = new FileWriter("C:/Users/User/Documents/NetBeansProjects/Project/shoukhin/profile.txt", true);
					BufferedWriter bw = new BufferedWriter(ob96);
					bw.write("Name = " + s1 + "\n");
					bw.close();
				} catch (Exception ex) {
					System.out.println(ex);
				}

			}
			if (e.getSource() == ob5) {
				String age = ob5.getText();
				System.out.println("age=" + age);
				try {
					FileWriter ob95 = new FileWriter("C:/Users/User/Documents/NetBeansProjects/Project/shoukhin/profile.txt", true);
					BufferedWriter bw = new BufferedWriter(ob95);
					bw.write("age = " + age + "\n");
					bw.close();
				} catch (Exception ex) {
					System.out.println(ex);
				}
			}
			if (e.getSource() == ob10) {
				String weight = ob10.getText();
				System.out.println("Weight=" + weight);
				try {
					FileWriter ob97 = new FileWriter("C:/Users/User/Documents/NetBeansProjects/Project/shoukhin/profile.txt", true);
					BufferedWriter bw = new BufferedWriter(ob97);
					bw.write("Weight= " + weight + "\n");
					bw.close();
				} catch (Exception ex) {
					System.out.println(ex);
				}
			}
			if (e.getSource() == ob11) {
				String height = ob11.getText();
				System.out.println("Height=" + height);
				try {
					FileWriter ob97 = new FileWriter("C:/Users/User/Documents/NetBeansProjects/Project/shoukhin/profile.txt", true);
					BufferedWriter bw = new BufferedWriter(ob97);
					bw.write("Height = " + height + "\n");
					bw.close();
				} catch (Exception ex) {
					System.out.println(ex);
				}
			}
			if (e.getSource() == ob6) {
				int x = JOptionPane.showConfirmDialog(null, "Dou You want to create Another Account ? ", "Student Fitness", JOptionPane.YES_NO_OPTION);
				if (x == JOptionPane.YES_OPTION) {
					NewClass ob200 = new NewClass();
					
					ob200.setVisible(true);
				} else {
					JOptionPane.showMessageDialog(null, "Thanks", "student Fitness", JOptionPane.INFORMATION_MESSAGE);
					dispose();
				}

			}

		}

	}

	public static void main(String[] args) {
		Project2 ob = new Project2();
		ob.setVisible(true);
		ob.setBounds(500, 100, 600, 600);
		ob.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}

}
