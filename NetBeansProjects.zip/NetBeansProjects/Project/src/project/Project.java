
package project;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Project extends JFrame  {
    Project ()
    {
    fitness();
    }
    public void fitness()
    {
    Container ob1=new Container ();
    ob1=this.getContentPane();
    ob1.setLayout (null);
    ob1.setBackground(Color.green);
    
    Font ob50=new Font ("Nirmala UI",Font.BOLD,16);
    JTextArea jt=new JTextArea();
	jt.setBounds(10,300,400,400);
	ob1.add(jt);
	
    JLabel ob2=new JLabel();
    ob2.setOpaque(true);
    ob2.setBackground(Color.green);
    ob2.setBounds(10,10,130,50);
    ob2.setText("Enter name:");
    ob2.setFont(ob50);
    ob1.add(ob2);

    JTextField ob3=new JTextField();
    ob3.setBounds(145,10,200,50);
    ob3.setFont(ob50);
    ob1.add(ob3);
    
    JLabel ob4=new JLabel();
    ob4.setOpaque(true);
    ob4.setBackground(Color.green);
    ob4.setBounds(10,70,130,50);
    ob4.setText("Enter Roll:");
    ob4.setFont(ob50);
    ob1.add(ob4);
    
    JTextField ob5=new JTextField();
    ob5.setBounds(145,70,200,50);
    ob5.setFont(ob50);
    ob1.add(ob5);
    
    JButton ob6=new JButton();
    ob6.setText("জুমি");
    ob6.setBounds(150,200,80,50);
    ob6.setFont(ob50);
    ob1.add(ob6);
    
    
    ob6.addActionListener (new ActionListener (){
    public void actionPerformed(ActionEvent e)
    {
      JOptionPane.showMessageDialog(null,"Please input next student information","Student Fitness",JOptionPane.INFORMATION_MESSAGE);
              
    }
    });
    
    
    JButton ob7=new JButton();
    ob7.setText("সৌখিন");
    ob7.setBounds(265,200,80,50);
    ob7.setFont(ob50);
    ob1.add(ob7);
    
    
    JLabel ob8=new JLabel();
    ob8.setOpaque(true);
    ob8.setBackground(Color.green);
    ob8.setBounds(10,130,130,50);
    ob8.setText("Enter Password:");
    ob8.setFont(ob50);
    ob1.add(ob8);
    

    JTextField ob9=new JTextField();
    ob9.setBounds(145,130,200,50);
    ob9.setFont(ob50);
    ob1.add(ob9);
    
    
    
    
    
    
    }
     public static void main(String[] args) {
     Project ob=new Project(); 
     ob.setVisible(true);
     ob.setBounds(400,100,800,800);
     ob.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
 }