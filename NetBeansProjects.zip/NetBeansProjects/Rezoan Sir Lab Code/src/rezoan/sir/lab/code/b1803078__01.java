package rezoan.sir.lab.code;

import java.util.Scanner;
import java.util.Vector;

public class b1803078__01 {

	public static void main(String[] args) {
		Scanner ob = new Scanner(System.in);
		int n = ob.nextInt();
		int m = ob.nextInt();
		int a = ob.nextInt();
		int c = ob.nextInt();
		int x = ob.nextInt();
		if (n < 0) {
			System.out.println("Invalid Input");
		} else {
			Vector<Integer >v=new Vector();
			v.add(x);
			
			for (int i = 1; i < n; i++) {
				x = ((x * a) + c) % m;
				v.add(x);
			}
			System.out.println("Sequence = ");
			for(int i=0;i<v.size();i++){System.out.print(v.get(i)+" ");}
		}
	}
}
