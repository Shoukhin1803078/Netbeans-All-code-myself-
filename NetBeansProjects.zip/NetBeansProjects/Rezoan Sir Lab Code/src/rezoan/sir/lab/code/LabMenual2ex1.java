package rezoan.sir.lab.code;
import java.util.Scanner;
import java.util.Vector;

public class LabMenual2ex1 {
    public static void main(String [] args )
    {
     int x=7;
     int y=8;
     System.out.println(x|y);
     
     int m,n,o;
        
     Scanner ob=new Scanner (System.in);
     System .out .println("how many element you want to add in Universal set  :");
     m=ob.nextInt();
     
     
     Vector U=new Vector ();
     Vector u=new Vector ();
     System.out .println("Input universal set :");
     for (int i=0;i<m;i++)
     {
        U.add(ob.nextInt());
        u.add(1);
     }
     
     
     System .out .println("how many element you want to add in A set  :");
     n=ob.nextInt();
     Vector A=new Vector ();
     Vector a=new Vector ();
     System.out .println("Input A set :");
     for (int i=0;i<n;i++)
     {
         A.add(ob.nextInt());
         a.add(1);
     }
     
     
     System .out .println("how many element you want to add in B set  :");
     o=ob.nextInt();
     Vector B=new Vector ();
     Vector b=new Vector();
     System.out .println("Input B set :");
     for (int i=0;i<o;i++)
     {
         B.add(ob.nextInt());
         b.add(1);
     }
     
     System.out.println("U="+U);
     System.out.println("A="+A);
     System.out.println("B="+B);

     System.out.println("u="+u);
     System.out.println("a="+a);
     System.out.println("b="+b);
     
     
    }
}