package rezoan.sir.lab.code;

import java.util.Scanner;

public class Problem_4___1803078 {

	public static void main(String[] args) {
		Scanner ob = new Scanner(System.in);
		String n=ob.next();
		int m=ob.nextInt();
		int ans =0;
		for(int i=0;i<n.length();i++)
		{
		ans=((ans*10)+(n.charAt(i)-'0'))%m;
		}
		System.out.println(ans);
	}
}
