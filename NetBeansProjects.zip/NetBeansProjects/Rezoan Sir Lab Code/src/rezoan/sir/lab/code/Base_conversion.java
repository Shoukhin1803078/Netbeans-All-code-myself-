package rezoan.sir.lab.code;

import java.util.Scanner;
import java.util.Vector;

public class Base_conversion {
	public static void main(String[] args) {
		Scanner ob = new Scanner(System.in);
		System.out.println("Enter octal num:");
		String s = ob.next();
		Vector<Integer> v = new Vector();
		int sum = 0;
		for (int i = s.length() - 1, k = 0; i >= 0; i--) {
			sum += ((s.charAt(i) - '0') * Math.pow(8, k));
			k++;
		}
		System.out.println("decimal="+sum);
		while(sum!=0)
		{
		v.add(sum%2);
		sum=sum/2;
		}
		System.out.println(v);
	}
}
