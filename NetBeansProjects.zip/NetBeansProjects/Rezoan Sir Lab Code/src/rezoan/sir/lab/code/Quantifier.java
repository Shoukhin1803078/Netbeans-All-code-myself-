
package rezoan.sir.lab.code;

import java.util.Scanner;

public class Quantifier {
    
    public static void main(String [] args)
    {
      
        Scanner in=new Scanner(System.in);
        int a[]=new int[3];
        for (int i=0;i<a.length;i++)
        {
        a[i]=in.nextInt();
        }
        int b[]={2,3,4};
        
        int flag = 0;
        
        //ExVy P(x,y)          ;  p(x,y)=>y=x+2
    for (int x=0;x<a.length;x++)
    {
      for (int y=0;y<b.length;y++)
      {
         if(a[x]+2==(b[y]))
         {
         flag=0;
         break;
         }
         else
         {
         flag=1;
         }
      }
      if(flag==0)
      {
      break;
      }
      else
      {
      continue;
      }
    }
    if(flag==0)
    {
    System.out.println("T");
    }
    else 
       System.out.printf("f"); 
    }
}
