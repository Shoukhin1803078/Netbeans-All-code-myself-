package rezoan.sir.lab.code;

import java.util.Scanner;

public class s1803078_03 {

	public static void main(String[] args) {
		Scanner ob = new Scanner(System.in);
		int n = ob.nextInt();
		int a[] = new int[n];
		for (int i = 0; i < n; i++) {
			a[i] = ob.nextInt();
		}
		long t1 = System.currentTimeMillis();
		for (int j = 1; j < a.length; j++) {
			int t = a[j];
			for (int i = j; i >= 0; i--) {
				if (a[i] > t) {
					i++;
					a[i] = a[i - 1];
					a[i - 1] = t;
				}
			}
		}
		long t2 = System.currentTimeMillis();
		/*for (int i = 0; i < n; i++) {
			System.out.print(a[i] + " ");
		}*/
		
		System.out.println(t2 - t1);
	}

}
