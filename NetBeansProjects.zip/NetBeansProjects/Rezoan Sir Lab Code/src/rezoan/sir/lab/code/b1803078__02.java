
package rezoan.sir.lab.code;

import java.util.Scanner;

public class b1803078__02 {
	public static void main(String[] args) {
		Scanner ob=new Scanner(System.in);
		int a=ob.nextInt();
	}
}
