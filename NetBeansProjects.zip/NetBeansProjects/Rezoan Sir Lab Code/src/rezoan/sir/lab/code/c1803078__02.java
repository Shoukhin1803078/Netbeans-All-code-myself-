
package rezoan.sir.lab.code;

import java.util.Scanner;

public class c1803078__02 {
	public static  long f(long n)
	{
	if(n==0){return 1;}
	if(n==1){return 1;}
	return n*f(n-1);
	}
	public static void main(String[] args) {
		Scanner ob=new Scanner(System.in);
		long n=ob.nextInt();
		long r=ob.nextInt();
		long ans1=f(n)/f(n-r);
		long ans2=f(n)/(f(r)*f(n-r));
		System.out.println("P("+n+","+r+")="+ans1);
		System.out.println("C("+n+","+r+")="+ans2);
	}
}
