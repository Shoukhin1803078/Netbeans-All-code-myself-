
package rezoan.sir.lab.code;

import java.util.Scanner;

public class problem_1___1803078 {
	public static void main(String[] args) {
				Scanner ob=new Scanner(System.in);
				long a=ob.nextLong();
				long b=ob.nextLong();
				long c=ob.nextLong();
				long m=ob.nextLong();
				long x=((a%m)*(b%m))%m;
				long ans=((x%m)*(c%m))%m;
				System.out.println(ans);	
	}
}
