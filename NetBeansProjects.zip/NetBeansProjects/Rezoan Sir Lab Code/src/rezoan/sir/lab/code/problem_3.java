package rezoan.sir.lab.code;

import java.util.Scanner;
import java.util.Vector;

public class problem_3 {
	
	public static void main(String[] args) {
		Scanner ob = new Scanner(System.in);
		int n = ob.nextInt();
		if (n == 1) {
			System.out.println("This is not a prime number .Please enter another number grater than 1");
			System.exit(0);
		}
		boolean a[] = new boolean[n+1];
		Vector<Integer> v = new Vector();
		for (int i = 0; i <=n; i++) {
			a[i] = true;
		}
		for (int i = 2; i <= Math.sqrt(n); i++) {
			if (a[i] == true) {
				for (int j = i * i; j <=n; j += i) {
					a[j] = false;
				}
			}
		}
		for (int i = 2; i <=n; i++) {
			if (a[i] == true) {
				v.add(i);
			}
		}
		for (int i = 0; i < v.size(); i++) {
			System.out.println(v.get(i));
		}
		//System.out.println(v.size());
		
	}
}
