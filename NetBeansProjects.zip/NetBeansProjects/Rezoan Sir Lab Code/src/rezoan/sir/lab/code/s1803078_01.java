package rezoan.sir.lab.code;

import java.util.Arrays;
import java.util.Scanner;

public class s1803078_01 {

	public static void main(String[] args) {
		Scanner ob = new Scanner(System.in);
		int n = ob.nextInt();
		int a[] = new int[n];
		for (int i = 0; i < n; i++) {
			a[i] = ob.nextInt();
		}
		Arrays.sort(a);
		int x = ob.nextInt();
		long t1=System.currentTimeMillis();
		int pos = -1;
		int l = 0, r = a.length - 1, mid=0;
		while (l <= r) {
			mid = (l + r) / 2;
			if (a[mid] == x) {
				pos = mid;
				break;
			} else if (a[mid] < x) {
				l = mid + 1;
			} else {
				r = mid - 1;
			}
		}
		long t2=System.currentTimeMillis();
		System.out.println(pos);
		System.out.println(t2-t1);
		
	}
}
