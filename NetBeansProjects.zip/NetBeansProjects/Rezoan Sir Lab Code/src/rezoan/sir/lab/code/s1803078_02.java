package rezoan.sir.lab.code;

import java.util.Scanner;

public class s1803078_02 {

	public static void main(String[] args) {
		Scanner ob = new Scanner(System.in);
		int n = ob.nextInt();
		int a[] = new int[n];
		for (int i = 0; i < n; i++) {
			a[i] = ob.nextInt();
		}
		long t1=System.currentTimeMillis();
		for (int i = 0; i < n ; i++) {
			for (int j = 0; j < n-1-i; j++) {
				if (a[j] > a[j+1]) {
					int t = a[j];
					a[j] = a[j+1];
					a[j+1] = t;
				}
			}
		}
		long t2=System.currentTimeMillis();
		//System.out.println(t2-t1);
		for (int i = 0; i < n; i++) {
			System.out.print(a[i]+" ");
		}
		System.out.println();
		System.out.println(t2-t1);
	}
}
