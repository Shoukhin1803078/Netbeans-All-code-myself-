package rezoan.sir.lab.code;

import java.util.Scanner;
import java.util.Vector;

public class problem_2 {

	public static void main(String[] args) {
		Scanner ob = new Scanner(System.in);
		int b = ob.nextInt();
		int n = ob.nextInt();
		int m = ob.nextInt();
		int res = 1;
		int power = b % m;
		Vector<Integer> v = new Vector();
		while (n != 0) {
			v.add(n % 2);
			n = n / 2;
		}
		for (int i = 0; i < v.size(); i++) {
			if (v.get(i) == 1) {
				res = (res * power) % m;
			}
			power = (power * power) % m;
		}
		System.out.println(res);
	}
}
