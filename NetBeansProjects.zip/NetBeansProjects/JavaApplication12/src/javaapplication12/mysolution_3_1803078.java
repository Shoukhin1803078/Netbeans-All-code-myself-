
package javaapplication12;

import java.util.Scanner;

public class mysolution_3_1803078 {
	
	public static void main(String[] args) {
		Scanner ob=new Scanner (System.in);
		int n=ob.nextInt();
		if(n==0){System.out.println("0");}
		else{
		long sum=0;
		for(int i=1;i<=n;i++)
		{
		sum+=i*5;
		}
			System.out.println(sum);
		}
	}
}
