package javaapplication12;

import java.util.Arrays;
import java.util.Scanner;

public class mysolution_1_1803078 {

	public static void main(String[] args) {
		Scanner ob = new Scanner(System.in);
		int total_num_of_people = ob.nextInt();
		int total_time = ob.nextInt();
		int a[] = new int[total_num_of_people];
		//input each people speech minute
		for (int i = 0; i < a.length; i++) {
			a[i] = ob.nextInt();
		}
		Arrays.sort(a);
		int x = 0;
		int count = 0;
		for (int i = 0; i < a.length; i++) {
			x = x + a[i];

			if (x > total_time) {
				break;
			}
			count++;
		}
		System.out.println("number of people="+count);
	}
}
