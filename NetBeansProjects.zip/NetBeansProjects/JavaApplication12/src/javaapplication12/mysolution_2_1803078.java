package javaapplication12;

import java.util.Scanner;

public class mysolution_2_1803078 {

	static int fibonacci(int x) {
		if ((x == 1) || (x == 0)) {
			return (x);
		} else {
			return (fibonacci(x - 1) + fibonacci(x - 2));
		}
	}
	
	public static void main(String[] args) {
		Scanner ob=new Scanner (System.in);
		System.out.print("Enter n=");
		int n=ob.nextInt();
		n=n-1;
		System.out.println("nth term of fibonacci="+fibonacci( n));
	}
}
