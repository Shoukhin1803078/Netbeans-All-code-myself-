/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vector1;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class NewClass {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a1 = sc.nextInt();
		for (int i = 0; i < a1; i++) {
			int n = sc.nextInt();
			String s = sc.next();
			int a[]=new int[s.length()];
		for(int j=0;j<s.length();j++)
		{
		a[j]=(int )s.charAt(j);
		}for(int j=0;j<s.length();j++)
		{
			System.out.println(a[i]);
		}
		
			//char c[] = sc.next().toCharArray();
			Arrays.sort(a);
			for (int j = 0; j < a.length; j++) {
				System.out.print((char)a[i]);
			}
			System.out.println();
		}
	}
}
