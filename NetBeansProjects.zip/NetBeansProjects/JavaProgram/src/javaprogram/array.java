package javaprogram;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;
import java.util.Vector;

public class array {

	public static void main(String[] args) {
		Vector<Integer> v = new Vector();
		Stack<Integer> s = new Stack();
		Queue<Integer> q = new LinkedList();
		s.push(1);
		s.pop();
		s.push(2);
		s.push(3);
		s.push(4);
		s.push(5);
		System.out.println(s.peek());
		s.push(6);
		s.pop();
		s.push(7);
		s.pop();

		System.out.println(s);

		System.out.println(s);

	}
}
