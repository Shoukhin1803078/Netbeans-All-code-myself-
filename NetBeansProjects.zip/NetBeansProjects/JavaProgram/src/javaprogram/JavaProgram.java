package javaprogram;

import java.io.File;
import java.util.Formatter;
import java.util.Scanner;

public class JavaProgram {

	public static void main(String[] args) {
		int a[] = new int[5];
		int sum = 0;
		Scanner ob = new Scanner(System.in);
		System.out.printf("Please input any 5 number :");

		File ob1 = new File(" Filesave");
		ob1.mkdir();

		try {
			File ob2 = new File("C:\\Users\\User\\Documents\\NetBeansProjects\\JavaProgram\\ Filesave\\Filemaysave.txt");
			ob2.createNewFile();
			Formatter ob3 = new Formatter("C:\\Users\\User\\Documents\\NetBeansProjects\\JavaProgram\\ Filesave\\Filemaysave.txt");
			for (int i = 0; i < a.length; i++) {
				a[i] = ob.nextInt();
			}
			for (int i = 0; i < a.length; i++) {
				sum = sum + a[i];
			}
			System.out.println("sum is " + sum);
			ob3.format("You inputed:\n");
			for (int i = 0; i < a.length; i++) {
				ob3.format("%d\n", a[i]);
			}
			ob3.format("the sum is " + sum);
			ob3.close();//ati na dile file write honbe na

		} catch (Exception ex) {
			System.out.println(ex);
		}

	}
}
