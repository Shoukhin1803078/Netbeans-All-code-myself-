package javaprogram;

import java.util.Scanner;

 interface B1 {

}
public class B{

}
public class V{

}