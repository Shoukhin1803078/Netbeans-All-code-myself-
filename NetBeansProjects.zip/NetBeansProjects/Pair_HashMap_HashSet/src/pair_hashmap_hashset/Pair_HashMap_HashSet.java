/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pair_hashmap_hashset;

import java.util.Vector;
import javafx.util.Pair;

/**
 *
 * @author User
 */
public class Pair_HashMap_HashSet {

	
	public static void main(String[] args) {
		Vector<Pair<String,Integer>>v=new Vector();
		for(int i=0;i<10000;i++)
		{
		v.add(new Pair("abc",i));
		}
		for(int i=0;i<v.size();i++)
		{
			System.out.println("index="+i+" key="+v.get(i).getKey()+" value="+v.get(i).getValue());
		}
		v.add(new Pair("abc",1));
		v.add(new Pair("a",3));
		System.out.println(v);
		System.out.println(v.get(0).getKey());
		System.out.println(v.get(0).getValue());
	}
	
	
}
