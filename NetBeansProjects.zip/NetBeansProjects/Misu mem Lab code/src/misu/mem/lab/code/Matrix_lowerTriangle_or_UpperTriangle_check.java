package misu.mem.lab.code;

import java.util.Scanner;

public class Matrix_lowerTriangle_or_UpperTriangle_check {

	public static void main(String[] args) {
		Scanner ob = new Scanner(System.in);
		while (true) {
			System.out.println("enter row and column=");
			int n1 = ob.nextInt();
			int n2 = ob.nextInt();
			int x[][] = new int[n1][n2];
			for (int i = 0; i < n1; i++) {
				for (int j = 0; j < n2; j++) {
					x[i][j] = ob.nextInt();
				}
			}
			int k = 0;
			int k1 = 0;
			out:
			for (int col = 0; col < n2; col++) {
				for (int row = 0; row < n1; row++) {
					if (col > row) {
						if (x[row][col] == 0) {
							k = 0;
						} else {
							k = 1;
							break out;
						}
					}
				}
			}
			if (k == 0) {
				System.out.println("Matrix is Upper triangle ");
			} else {
				out:
				for (int col = 0; col < n2; col++) {
					for (int row = 0; row < n1; row++) {
						if (col < row) {
							if (x[row][col] == 0) {
								k1 = 0;
							} else {
								k1 = 1;
								break out;
							}
						}
					}
				}
				if (k1 == 0) {
					System.out.println("Matrix is Lower Triangle ");
				} else {
					System.out.println("This is Non Triangular matrix");
				}
			}
		}

	}

}
