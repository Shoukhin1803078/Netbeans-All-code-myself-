package misu.mem.lab.code;

import java.util.Scanner;

public class s1803078_Example6point10 {

	public static void main(String[] args) {
		Scanner ob = new Scanner(System.in);
		int n = 5;
		double x[] = new double[n];

		double y[] = new double[n];
		for (int i = 0; i < n; i++) {
			x[i] = ob.nextDouble();
			y[i] = 1 / (1 + x[i]);
		}
		System.out.println("-------------table------------ \n x\t y");
		for (int i = 0; i < n; i++) {
			System.out.println(x[i] + "\t" + y[i]);
		}

		double sum = 0;
		for (int i = 0; i < n; i++) {
			if (i == 0 || i == y.length - 1) {
				if (i == 0) {
					sum += y[i];
				} else {
					sum += y[i];
				}
			} else {
				sum += (2 * y[i]);
			}
		}

		double h = x[1] - x[0];
		System.out.println();
		System.out.printf("Trapezoidal rule ans = %.4f", (h / 2) * sum);
		System.out.println();

		double sum1 = 0;
		for (int i = 0; i < n; i++) {
			if (i == 0 || i == y.length - 1) {
				if (i == 0) {
					sum1 += y[i];
				} else {
					sum1 += y[i];
				}
			} else {
				if (i % 2 == 0) {
					sum1 += 2 * y[i];
				} else {
					sum1 += 4 * y[i];
				}
			}
		}
		
		System.out.printf("Simpson One-third rule ans= %.4f ", (h/3)*sum1);

	}
}

/*
0.00
0.25
0.50
0.75
1.00
 */
