package misu.mem.lab.code;

import java.util.Scanner;

public class NewtonsForward_sir {

	static int n = 4;
	static int x[] = new int[n];
	static int y[][] = new int[n][n];

	static int factorial(int n) {
		if (n == 1) {
			return 1;
		}
		return n * factorial(n - 1);
	}

	static double p_value(int n, double p) {
		double p_original = p;
		for (int i = 1; i < n; i++) {
			p_original *= (p - i);
		}
		return p_original;
	}

	static double interpolation(double value) {
		double result = y[0][0];
		double h = x[1] - x[0];
		double p = (value - x[0]) / h;
		for (int i = 1; i < n; i++) {
			result += (p_value(i, p) * y[0][i]) / factorial(i);
		}
		return result;
	}

	public static void main(String[] args) {
		Scanner ob = new Scanner(System.in);

		for (int i = 0; i < n; i++) {
			x[i] = ob.nextInt();
			y[i][0] = ob.nextInt();
		}

		for (int i = 1; i < n; i++) {
			for (int j = 0; j < n - i; j++) {
				y[j][i] = y[j + 1][i - 1] - y[j][i - 1];
			}
		}
		for (int i = 0; i < n; i++) {
			System.out.print(x[i] + "\t");
			for (int j = 0; j < n-i ; j++) {
				System.out.print(y[i][j] + "\t");
			}
			System.out.println();
		}
	/*	while (true) {
			double value = ob.nextDouble();
			if (value == 0) {
				break;
			}*/
		System.out.println("Enter x=");
	                      double value = ob.nextDouble();
			System.out.println("Ans="+interpolation(value));
		//}

	}
}
/*
1 24
3 120 
5 336
7 720
 */
