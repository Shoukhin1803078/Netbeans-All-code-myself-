package misu.mem.lab.code;

import java.util.Collections;
import java.util.Scanner;
import java.util.Vector;

public class Matrix_Norm {

	public static void main(String[] args) {
		Scanner ob = new Scanner(System.in);
		System.out.println("enter row and column =");
		int n1 = ob.nextInt();
		int n2 = ob.nextInt();
		int x[][] = new int[n1][n2];
		for (int i = 0; i < n1; i++) {
			for (int j = 0; j < n2; j++) {
				x[i][j] = ob.nextInt();
			}
		}
		Vector v1 = new Vector();
		Vector v2 = new Vector();
		long sum2 = 0;
		long sum1 = 0;
		long sum3 = 0;
		
		for (int row = 0; row < n1; row++) {
			for (int col = 0; col < n2; col++) {
				sum1 += x[row][col];
				sum3+=x[row][col]*x[row][col];
			}
			v1.add(sum1);
			sum1 = 0;
		}
		for (int col = 0; col < n2; col++) {
			for (int row = 0; row < n1; row++) {
				sum2 += x[row][col];
			}
			v2.add(sum2);
			sum2 = 0;
		}
		System.out.println("column norm="+Collections.max(v2));
		System.out.println("row norm="+Collections.max(v1));
		System.out.println("euclidian norm="+Math.sqrt(sum3));
	
	}
}
