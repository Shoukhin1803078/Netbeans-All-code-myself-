package misu.mem.lab.code;

import java.util.Scanner;

public class Newtons_Forward_1803078 {

	static double factorial(int x) {
		if (x == 1) {
			return 1;
		}
		return x * factorial(x - 1);
	}

	static double p_val(double p1, int x) {
		double mul = 1;
		for (int i = 0; i < x; i++) {
			mul = mul * (p1 - i);
		}
		return mul;
	}

	static double result(double y[][], double p, double h, int n) {
		double sum = y[0][0];
		for (int i = 1; i < n; i++) {
			sum += ((p_val(p, i) * y[0][i]) / factorial(i));
		}
		return sum;
	}

	public static void main(String[] args) {
		Scanner ob = new Scanner(System.in);
		int n = 4;
		double x[] = new double[n];
		double y[][] = new double[n][n];
		for (int i = 0; i < n; i++) {
			x[i] = ob.nextDouble();
			y[i][0] = ob.nextDouble();
		}
		for (int j = 1; j < n; j++) {
			for (int i = 0; i < n - j; i++) {
				y[i][j] = y[i + 1][j - 1] - y[i][j - 1];
			}
		}
		for (int i = 0; i < n; i++) {
			System.out.print(x[i] + "\t");
			for (int j = 0; j < n - i; j++) {
				System.out.print(y[i][j] + "\t");
			}
			System.out.println();
		}
		System.out.println();
		System.out.print("Enter x= ");
		double xx = ob.nextDouble();
		double h = x[1] - x[0];
		double p = (xx - x[0]) / h;
		System.out.println("Ans="+result(y, p, h, n));
	}
}
/*
1 24
3 120
5 336
7 720
*/