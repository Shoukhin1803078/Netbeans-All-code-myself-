/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package misu.mem.lab.code;

/**
 *
 * @author User
 */
public class NumericalIntegrationTrapizoidalRule {
	
}
/*
1 2.7183
1.2 3.3201
1.4 4.0552
1.6 4.9530
1.8 6.0496
2.0 7.3891
2.2 9.0250
 */