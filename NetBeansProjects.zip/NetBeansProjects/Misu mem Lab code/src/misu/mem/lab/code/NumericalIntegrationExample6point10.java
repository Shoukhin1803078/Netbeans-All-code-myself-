
package misu.mem.lab.code;

import java.util.Scanner;

public class NumericalIntegrationExample6point10 {
	public static void main(String[] args) {
		Scanner ob=new Scanner (System.in);
		int n=ob.nextInt();
		double x[]=new double[n];
		double  y[]=new double[n];
		for(int i=0;i<n;i++)
		{
		x[i]=ob.nextDouble();
		y[i]=1.0/(1+x[i]);
		}
		System.out.println(result(y,n));
	}
	static double result(double y[],int n)
	{
	
	}
}
