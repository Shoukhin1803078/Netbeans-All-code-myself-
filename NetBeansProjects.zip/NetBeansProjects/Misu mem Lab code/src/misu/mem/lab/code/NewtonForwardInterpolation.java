
package misu.mem.lab.code;

import java.util.Scanner;
import java.util.Vector;

public class NewtonForwardInterpolation {
    public static void main(String [] args)
    {
       Vector x=new Vector ();
       Scanner ob=new Scanner (System.in);
       for (int i=0;i<5;i++)
       {
          x.add(ob.nextDouble());
       }
       System.out .println(x);
       
       Vector y=new Vector ();
       for (int i=0;i<5;i++)
       {
          y.add(ob.nextDouble());
       }
       System.out .println(y);
       
       Vector D1=new Vector ();
        for (int i=0;i<5;i++)
       {
        
       }
       
    }
    
}
