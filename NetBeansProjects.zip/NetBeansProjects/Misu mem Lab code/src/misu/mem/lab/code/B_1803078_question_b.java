package misu.mem.lab.code;

import java.util.Scanner;

public class B_1803078_question_b {

	public static void main(String[] args) {
		Scanner ob = new Scanner(System.in);
		int n = 4;
		double x1[] = new double[4];
		double y1[] = new double[4];
		double X[] = new double[4];
		double Y[] = new double[4];
		double XX[] = new double[4];
		double XY[] = new double[4];
		double sumX = 0;
		double sumXX = 0;
		double sumY = 0;
		double sumXY = 0;
		for (int i = 0; i < n; i++) {
			x1[i] = ob.nextDouble();
			double a = Math.log10(x1[i]);
			y1[i] = ob.nextDouble();
			double b = Math.log10(y1[i]);
			X[i] = a;
			Y[i] = b;
			XX[i] = a * a;
			XY[i] = a * b;
			sumX += a;
			sumY += b;
			sumXY += a * b;
			sumXX += a * a;
		}
		System.out.println("--------------------table-------------------");
		System.out.println("x\ty\t\tX\t\t\tY\t\t\tXX\t\t\tXY");
		for (int i = 0; i < n; i++) {
			System.out.println(x1[i] + "\t" + y1[i] + "\t" + X[i] + "\t" + Y[i] + "\t" + XX[i] + "\t" + XY[i]);
		}
		double a1 = (sumXY - ((sumX * sumY) * (1.0) / n)) / (sumXX - ((sumX * sumX) * (1.0) / n));
		double a00 = (sumY - sumX * a1) / n;
		double a0 = Math.pow(10, a00);
		
		System.out.printf("a= %.4f \n",a0);
		System.out.printf("b= %.4f \n",a1);
	}
}
/*
61 350
26 400
7 500
2.6 600
 */
