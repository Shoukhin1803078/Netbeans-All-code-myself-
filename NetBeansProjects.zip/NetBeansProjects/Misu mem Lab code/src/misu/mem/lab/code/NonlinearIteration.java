package misu.mem.lab.code;
import java.lang.Math;
import java.util.Scanner;
public class NonlinearIteration {
    static double f1(double x,double y)
    {
    return Math.sqrt(y*y+4);
    }
    static double g1(double x,double y)
    {
    return Math.sqrt(16-x*x);
    }
    
    public static void main(String [] args )
    {
        double x0,y0;
        System.out.println("Input any two aproximate root ");
        Scanner ob=new Scanner (System.in);
        x0=ob.nextDouble();
        y0=ob.nextDouble();
        double a[]=new double[100];
        double b[]=new double[100];
        a[0]=f1(x0,y0);
        b[0]=g1(x0,y0);
        
        for (int i=0;i<10;i++)
        {
          a[i+1]=  f1(a[i],b[i]);
          b[i+1]=g1(a[i],b[i]);
        }
        for (int i=0;i<10;i++)
        {
            System.out.println("x"+(i+1)+"="+a[i]);
            System.out.println("y"+(i+1)+"="+b[i]); 
        }
        System.out.println("root is "+a[2]+","+b[2]);
        
    }  
}