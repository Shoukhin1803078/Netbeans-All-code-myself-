package misu.mem.lab.code;

import java.util.Scanner;

public class NonLinearNewtonrapson {
    public static double dfdx(double x,double y)
     {
           return 2*x;
     }
     static double dfdy(double x,double y)
     {
        return -2*y;
     }
     static double dgdx(double x,double y)
     {
     return 2*x;
     } 
     static double dgdy(double x,double y)
     {
      return 2*y;
     }
     static double f(double x0,double y0)
     {
           return x0*x0-y0*y0-4;
     }
     static double g(double x0,double y0)
     {
           return x0*x0+y0*y0-16;
     }
      static double D(double x0,double y0)
     {
       return (dfdx(x0,y0)*dgdy(x0,y0))-(dgdx(x0,y0)*dfdy(x0,y0));
     }
      static double  h(double x0,double y0)
      {
     return (1/D(x0,y0))*((-f(x0,y0)*dgdy(x0,y0))-(-g(x0,y0)*dfdy(x0,y0)));
      }
      static double k(double x0,double y0)
      {
      return 1/D(x0,y0)*((dfdx(x0,y0)*-g(x0,y0))-(dgdx(x0,y0)*-f(x0,y0)));
      }
      
    public static void main(String [] args )
    {
          double x0,y0;
          System.out.println("Input any two approximate root :");
          Scanner ob=new Scanner (System.in);
          x0=ob.nextDouble();
          y0=ob.nextDouble();
          double x1,y1;
          x1=x0+h(x0,y0);
          y1=y0+k(x0,y0);
          System.out.println("x1="+x1);
          System.out.println("y1="+y1);
          
    }
   }