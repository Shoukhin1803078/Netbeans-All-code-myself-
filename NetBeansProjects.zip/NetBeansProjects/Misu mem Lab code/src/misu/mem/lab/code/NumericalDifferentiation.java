package misu.mem.lab.code;

import java.util.Scanner;

public class NumericalDifferentiation {

	public static void main(String[] args) {
		Scanner ob = new Scanner(System.in);
		double x[] = new double[7];
		double y[][] = new double[7][7];
		for (int i = 0; i < y.length; i++) {
			x[i] = ob.nextDouble();
			y[i][0] = ob.nextDouble();
		}
		for (int j = 1; j < 7; j++) {
			for (int i = j; i < 7; i++) {
				y[i][j] = y[i][j - 1] - y[i - 1][j - 1];
			}
		}
		System.out.println("x\ty\td\td2\td3\td4\td5\td6\t");
		for (int i = 0; i < y.length; i++) {
			System.out.print(x[i] + "\t");
			for (int j = 0; j < 7; j++) {
				System.out.printf("%.4f\t", y[i][j]);
			}
			System.out.println();
		}
		System.out.println();
		double h = .2;
		double sum = 0;
		for (int i = 2; i < 7; i++) {
			if (i % 2 == 0) {
				sum += ((1.0 / (i - 1)) * (y[i][i - 1]));
				/*
24
120
336
720
*/
			} else {
				/*
24
120
336
720
*/
				sum -= ((1.0 / (i - 1)) * (y[i][i - 1]));
			}
		}
		System.out.println((1.0/h)*sum);
	}
}


