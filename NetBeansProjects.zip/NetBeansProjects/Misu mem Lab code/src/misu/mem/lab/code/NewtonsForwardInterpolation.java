
package misu.mem.lab.code;
import java.util.Scanner ;
public class NewtonsForwardInterpolation {
   
    public static void main(String [] args)
    {
    double x,h,p;
    double  x1[]=new double []{.10,.15,.20,.25,.30};
    double y1[]=new double []{.1003,.1511,.2027,.2553,.3093};
    for (int i=0;i<x1.length;i++)
    {
        System.out.println(x1[i]+"\t"+y1[i]);
    }
    
    double dell1[]=new double [4];
    double dell2[]=new double [3];
    double dell3[]=new double [2];
    double dell4[]=new double [1];
    
    for (int i=0;i<5;i++)
    {
      dell1[i]=y1[i+1]-y1[i];
    }
    for (int i=0;i<dell1.length;i++)
    {
      dell2[i]=dell1[i+1]-dell1[i];
    }
    for (int i=0;i<dell1.length;i++)
    {
      dell3[i]=dell2[i+1]-dell2[i];
    }
    for (int i=0;i<dell1.length;i++)
    {
      dell4[i]=dell3[i+1]-dell3[i];
    }
    
    
    Scanner ob=new Scanner (System.in);
    System.out.println("input x=");
    x=ob.nextDouble();
    
    System.out.println("input h=");
    h=ob.nextDouble();
    double x0=x1[0];
    p=(x-x0)/h;
    
    
    }
   
}
