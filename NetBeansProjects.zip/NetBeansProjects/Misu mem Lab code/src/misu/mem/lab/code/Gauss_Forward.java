package misu.mem.lab.code;

import java.util.Scanner;

public class Gauss_Forward {

	static double xx[] = {.20, .22, .24, .26, .28, .30};
	static double yy[] = {1.6596, 1.6698, 1.6804, 1.6912, 1.7024, 1.7139};
	static double d[][] = new double[5][5];

	static void table() {
		for (int i = 0; i < 5; i++) {
			d[i][0] = yy[i + 1] - yy[i];
		}
		for (int i = 0; i < 4; i++) {
			d[i][1] = d[i + 1][0] - d[i][0];
		}
		for (int i = 0; i < 3; i++) {
			d[i][2] = d[i + 1][1] - d[i][1];
		}
		for (int i = 0; i < 2; i++) {
			d[i][3] = d[i + 1][2] - d[i][2];
		}
		for (int i = 0; i < 1; i++) {
			d[i][4] = d[i + 1][3] - d[i][3];
		}
		tableDisplay();
	}

	static void tableDisplay() {
		System.out.println("x     y");
		for (int i = 0; i < 6; i++) {
			System.out.println(xx[i] + " " + yy[i] + " ");
		}
		System.out.println();
		System.out.println("d           d2         d3         d4          d5");
		int k = 5;
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				if (j < k) {
					System.out.printf("%.7f  ", d[i][j]);
				}
			}
			System.out.println();
			k--;
		}
	}

	static int fact(int n) {
		if (n == 1) {
			return 1;
		}
		return n * fact(n - 1);
	}

	public static void main(String[] args) {
		Scanner ob = new Scanner(System.in);
		double x = ob.nextDouble();
		double h = xx[1] - xx[0];
		double p = (x - xx[0]) / h;
		table();
	}
}
