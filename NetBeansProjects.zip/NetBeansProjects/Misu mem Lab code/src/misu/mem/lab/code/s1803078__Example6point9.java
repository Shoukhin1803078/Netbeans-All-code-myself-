package misu.mem.lab.code;

import java.text.DecimalFormat;
import java.util.Scanner;

public class s1803078__Example6point9 {

	static double result(double yy[], int n, double h) {
		double sum = 0;
		for (int i = 0; i < yy.length; i++) {
			if (i == 0) {
				sum += yy[i];
			} else if (i == yy.length - 1) {
				sum += yy[i];
			} else if (i % 2 == 0) {
				sum += (2 * yy[i]);
			} else {
				sum += (4 * yy[i]);
			}
		}

		return ((Math.PI * h) / 3) * sum;
	}

	public static void main(String[] args) {
		//Example 6.9 
		Scanner ob = new Scanner(System.in);
		DecimalFormat df = new DecimalFormat("#.####");
		int n = 5;
		double x[] = new double[n];
		double y[] = new double[n];
		double yy[] = new double[n];
		for (int i = 0; i < n; i++) {
			x[i] = ob.nextDouble();
			y[i] = ob.nextDouble();
			double a = y[i] * y[i];
			String s = df.format(a);
			yy[i] = Double.parseDouble(s);
		}
		System.out.println("-----------Table---------\nx\ty^2");
		for (int i = 0; i < n; i++) {
			System.out.print(x[i] + "\t");
			System.out.println(yy[i] + "\t");
		}
		double h = x[1] - x[0];

		System.out.println("Ans=" + result(yy, n, h));
	}
}
/*
0.00 1.0000
0.25 0.9896
0.5 0.9589
0.75 0.9089
1.00 0.8415
*/