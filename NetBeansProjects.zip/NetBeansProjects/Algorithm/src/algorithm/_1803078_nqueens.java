

import java.util.Scanner;

public class _1803078_nqueens{


	public static void main(String[] args){
		
		Scanner ob=new Scanner(System.in);
		int x=ob.nextInt();
		System.out.println(x);
	}
}
