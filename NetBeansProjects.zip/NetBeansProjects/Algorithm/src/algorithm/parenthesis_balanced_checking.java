/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algorithm;

import java.util.Scanner;
import java.util.Stack;

public class parenthesis_balanced_checking{

	public static void main(String[] args){
		Scanner ob=new Scanner(System.in);
		String s=ob.next();
		Stack<Character> st=new Stack();
		for(int i=0;i<s.length();i++){
			char c=s.charAt(i);
			if(c=='('||c=='{'||c=='['){
				st.push(c);
			}else if(c==')' &&(st.isEmpty()||st.pop()!='(') ){
				System.out.println("false");System.exit(0);
			}
			else if(c=='}' &&(st.isEmpty()||st.pop()!='{') ){
				System.out.println("false");System.exit(0);
			}
			else if(c==']' &&(st.isEmpty()||st.pop()!='[') ){
				System.out.println("false");System.exit(0);
			}
		}
		System.out.println("true");
	}
}
