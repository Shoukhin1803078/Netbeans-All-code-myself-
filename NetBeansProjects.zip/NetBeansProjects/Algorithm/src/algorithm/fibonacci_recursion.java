/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algorithm;

import java.util.Scanner;

public class fibonacci_recursion{

	static int fibo(int n){
		if(n<0){

		}
		if(n==0){
			return 0;
		}else if(n==1){
			return 1;
		}
		long sum=0;
		return fibo(n-1)+fibo(n-2);
	}

	public static void main(String[] arg){
		Scanner ob=new Scanner(System.in);
		int n=ob.nextInt();
		for(int i=1;i<=n;i++)
		{
			System.out.println(fibo(i));
		}
		
	}
}
