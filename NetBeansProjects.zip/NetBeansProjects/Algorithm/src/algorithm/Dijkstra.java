
package algorithm;

import java.util.Scanner;

public class Dijkstra{

	public static void dijkstra(int[][] graph,int source,int start_node,int end_node){
		int count=graph.length;
		boolean[] visitedVertex=new boolean[count+1+1];
		int[] distance=new int[count];
		for(int i=1;i<count;i++){
			visitedVertex[i]=false;
			distance[i]=Integer.MAX_VALUE;
		}

		
		distance[source]=0;
		for(int i=1;i<count;i++){
			int u=findMinDistance(distance,visitedVertex);
			visitedVertex[u]=true;
			for(int v=1;v<count;v++){
				if(!visitedVertex[v]&&graph[u][v]!=0&&(distance[u]+graph[u][v]<distance[v])){
					distance[v]=distance[u]+graph[u][v];
				}
			}
		}
		System.out.println("Shortest distance from node "+start_node+"th  to node "+ end_node+"th is : "+distance[end_node]);

	}

	private static int findMinDistance(int[] distance,boolean[] visitedVertex){
		int minDistance=Integer.MAX_VALUE;
		int minDistanceVertex=-1;
		for(int i=1;i<distance.length;i++){
			if(!visitedVertex[i]&&distance[i]<minDistance){
				minDistance=distance[i];
				minDistanceVertex=i;
			}
		}
		return minDistanceVertex;
	}

	public static void main(String[] args){
		Scanner ob=new Scanner (System.in);
		int v=ob.nextInt();
		int e=ob.nextInt();
            	int graph[][]=new int[v+1][v+1];
		
		
		for(int j=0;j<e;j++)
		{
		int v1=ob.nextInt();
		int v2=ob.nextInt();
		int cost=ob.nextInt();
		graph[v1][v2]=cost;
		graph[v2][v1]=cost;
		
		}
		
		System.out.println("matrix representation is : ");
		for(int i=1;i<graph.length;i++)
		{
		for(int j=1;j<graph[0].length;j++)
		{
			System.out.print(graph[i][j]+" ");
		}
			System.out.println();
		}
		Dijkstra T=new Dijkstra();
		System.out.print("enter start node :");
		int start_node =ob.nextInt();
		System.out.print("enter end node: ");
		int end_node=ob.nextInt();
		//long t11=System.nanoTime();
	            long t1=System.currentTimeMillis();
		T.dijkstra(graph,start_node,start_node,end_node);
		long t2=System.currentTimeMillis();
		//long t22=System.nanoTime();
		System.out.println("Time taken : "+(t2-t1)+" mili sec");
	}
}

/*
3 2
1 2 5
2 3 8
*/
/*
0 5 0 
5 0 8 
0 8 0 
*/
/*
5 13
1 2 4
1 3 8
2 1 4
2 3 2
2 4 5
3 1 8
3 2 2
3 4 5
3 5 9
4 2 5
4 3 5
4 5 4
5 3 9
*/
/*
5 12 
1 2 3 
1 3 2 
2 1 3 
2 3 5 
2 4 3
3 1 2 
3 2 5 
3 5 20
4 2 3
4 5 4
5 3 20
5 4 4 
1 5 
*/

/*
10 42 40
81 17 46
68 88 62
87 74 70
64 25 81 
21 74 65 
75 32 64 
76 16 53 
99 22 42 
31 44 72 
59 25 55
74 73 79 
50 81 50 
20 96 70 
87 97 41 
79 14 47 
14 53 84
96 46 67 
82 3 82 
46 17 35 
81 9 50 
100 85 72 
82 25 50
49 50 65 
90 2 47
78 73 4
60 50 75 
26 88 44
65 4 50 
39 23 81 
38 6 68
97 24 20
79 42 58
11 50
*/