
package algorithm;

import javafx.util.Pair;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Scanner;

public class Dijksta_PQ{

	static class Edge{

		int source;
		int destination;
		int weight;

		public Edge(int source,int destination,int weight){
			this.source=source;
			this.destination=destination;
			this.weight=weight;
		}
	}

	static class Graph{

		int vertices;
		static LinkedList<Edge>[] adjacencylist;

		Graph(int vertices){
			this.vertices=vertices;
			adjacencylist=new LinkedList[vertices];
			
			for(int i=0;i<vertices;i++){
				adjacencylist[i]=new LinkedList<>();
			}
			
		}

		public void addEdge(int source,int destination,int weight){
			Edge edge=new Edge(source,destination,weight);
			adjacencylist[source].addFirst(edge);

			edge=new Edge(destination,source,weight);
			adjacencylist[destination].addFirst(edge); 
		}
		
		

		public void dijkstra_GetMinDistances(int sourceVertex,int start,int end){

			boolean[] SPT=new boolean[vertices];
			
			int[] distance=new int[vertices];

			
			for(int i=0;i<vertices;i++){
				distance[i]=Integer.MAX_VALUE;
			}
			
			PriorityQueue<Pair<Integer,Integer>> pq=new PriorityQueue<>(vertices,new Comparator<Pair<Integer,Integer>>(){
				
				public int compare(Pair<Integer,Integer> p1,Pair<Integer,Integer> p2){
					
					int key1=p1.getKey();
					int key2=p2.getKey();
					return key1-key2;
				}
			});
			
			distance[0]=0;
			Pair<Integer,Integer> p0=new Pair<>(distance[0],0);
		
			pq.offer(p0);

			while(!pq.isEmpty()){
				
				Pair<Integer,Integer> extractedPair=pq.poll();

				int extractedVertex=extractedPair.getValue();
				if(SPT[extractedVertex]==false){
					SPT[extractedVertex]=true;

					LinkedList<Edge> list=adjacencylist[extractedVertex];
					for(int i=0;i<list.size();i++){
						Edge edge=list.get(i);
						int destination=edge.destination;
						
						if(SPT[destination]==false){
							
							int newKey=distance[extractedVertex]+edge.weight;
							int currentKey=distance[destination];
							if(currentKey>newKey){
								Pair<Integer,Integer> p=new Pair<>(newKey,destination);
								pq.offer(p);
								distance[destination]=newKey;
							}
						}
					}
				}
			}
			printDijkstra(distance,sourceVertex,start,end);
		}

		public void printDijkstra(int[] distance,int sourceVertex,int start,int end){
			
			System.out.println("Shortest distance from "+start+"th to "+end+"th is : "+distance[end-1]);
			
		}

		public static void main(String[] args){
			Scanner ob=new Scanner(System.in);
			
			int v=ob.nextInt();
			int  e=ob.nextInt();
			Graph graph=new Graph(v);
			for(int i=0;i<e;i++)
			{
				int u1=ob.nextInt();
				int v1=ob.nextInt();
				int c=ob.nextInt();
				
			graph.addEdge(u1-1,v1-1,c);
			}
			
			System.out.println("enter start node:");
			int start=ob.nextInt();
			System.out.println("enter end node:");
			int end=ob.nextInt();
			double  t1=System.currentTimeMillis();
			graph.dijkstra_GetMinDistances(start-1,start,end);
			double t2=System.currentTimeMillis();
			System.out.println("Time take: "+(t2-t1)+" mili sec ");
			
		}
	}
}
