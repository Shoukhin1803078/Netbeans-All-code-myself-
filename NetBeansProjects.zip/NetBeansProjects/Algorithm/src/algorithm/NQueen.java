
package algorithm;

import java.util.*;

class Main{

	public static void main(String[] args){
		Scanner in=new Scanner(System.in);

		System.out.print("Enter Queens: ");
		int n=in.nextInt();

		NQueen nQueen=new NQueen(n);
		nQueen.solve();
	}
}

class NQueen{

	int n;
	int board[][];
	boolean hasSolution=false;

	//constructor takes N as a parameter
	NQueen(int n){
		this.n=n;
		board=new int[n][n];
	}

	//function display the board configurations
	private void printBoard(){
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				if(board[i][j]==1){
					System.out.print("* ");
				}else{
					System.out.print("- ");
				}
			}
			System.out.println();
		}
		System.out.println("\n");
	}

	public void solve(){
		
		solveColumn(0);
		if(!hasSolution){
			System.out.println("No Solution");
		}
	}

	private void solveColumn(int col){
	
		if(col==n){
			hasSolution=true;
			printBoard();
			return;
		}

		//loop through the current column cells
		for(int i=0;i<n;i++){
			//check if the current cell is safe to place a queen
			if(isValidPlace(i,col)){
				//if yes then place the queen - change value to 1 and
				//move to the next column
				board[i][col]=1;
				solveColumn(col+1);
				//backtrack - reset to 0 means removing queen
				board[i][col]=0;
			}

		}
	}

	//function checks if the position (r,c) is safe     
	private boolean isValidPlace(int r,int c){
		//Check horizontally (left)
		for(int j=c;j>=0;j--){
			if(board[r][j]==1){
				return false;
			}
		}

		//check the left diagonal
		for(int i=r, j=c;i>=0&&j>=0;i--,j--){
			if(board[i][j]==1){
				return false;
			}
		}

		//check the right diagonal
		for(int i=r, j=c;i<n&&j>=0;i++,j--){
			if(board[i][j]==1){
				return false;
			}
		}

		//return true because it is safe
		return true;
	}
}
