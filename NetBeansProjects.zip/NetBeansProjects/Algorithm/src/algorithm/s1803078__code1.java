
package algorithm;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class s1803078__code1 {

	static long count = 0;
	static int n;
	static int a[];

	static void MaxMin() {
		int max = a[0];
		int min = a[0];
		for (int i = 1; i < a.length; i++) {
			count+=2;
			if (max < a[i]) {
				max = a[i];
			}
			
			if (min > a[i]) {
				min = a[i];
			}
		}
		
		System.out.println("max=" + max + " " + "\nmin=" + min);
		System.out.println("Number of comparison:"+count);
	}

	public static void main(String[] args) {

		Scanner ob = new Scanner(System.in);
		File f = new File("MaxMin1.txt");
		try {
			Scanner sc = new Scanner(f);
			while (sc.hasNext()) {
				String s = sc.nextLine();
				n = Integer.valueOf(s);
				a = new int[n];
				for (int i = 0; i < n; i++) {
					a[i] = Integer.valueOf(sc.next());
				}
				MaxMin();
			}
		} catch (Exception e) {
			System.out.println("exception is found");
		}
	}
}
