/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algorithm;

import java.util.Scanner;

public class Dijkstra_unsorted{


	public static void dijkstra(int[][] graph,int source,int start_node,int end_node){
		int count=graph.length;
		boolean[] visitedVertex=new boolean[count+1+1];
		int[] distance=new int[count];
		for(int i=1;i<count;i++){
			visitedVertex[i]=false;
			distance[i]=Integer.MAX_VALUE;
		}

		
		distance[source]=0;
		for(int i=1;i<count;i++){
			int u=findMinDistance(distance,visitedVertex);
			visitedVertex[u]=true;
			for(int v=1;v<count;v++){
				if(!visitedVertex[v]&&graph[u][v]!=0&&(distance[u]+graph[u][v]<distance[v])){
					distance[v]=distance[u]+graph[u][v];
				}
			}
		}
		System.out.println("Shortest distance from "+start_node+"th  to "+ end_node+"th is : "+distance[end_node]);

	}

	private static int findMinDistance(int[] distance,boolean[] visitedVertex){
		int minDistance=Integer.MAX_VALUE;
		int minDistanceVertex=-1;
		for(int i=1;i<distance.length;i++){
			if(!visitedVertex[i]&&distance[i]<minDistance){
				minDistance=distance[i];
				minDistanceVertex=i;
			}
		}
		return minDistanceVertex;
	}

	public static void main(String[] args){
		Scanner ob=new Scanner (System.in);
		int v=ob.nextInt();
		int e=ob.nextInt();
		//e=2*e;
		int graph[][]=new int[v+1][v+1];
		
		
		for(int j=0;j<e;j++)
		{
		int v1=ob.nextInt();
		int v2=ob.nextInt();
		int cost=ob.nextInt();
		graph[v1][v2]=cost;
		graph[v2][v1]=cost;
		
		}
		
		System.out.println("graph representation is : ");
		for(int i=1;i<graph.length;i++)
		{
		for(int j=1;j<graph[0].length;j++)
		{
			System.out.print(graph[i][j]+" ");
		}
			System.out.println();
		}
		Dijkstra T=new Dijkstra();
		System.out.println("enter start node :");
		int start_node =ob.nextInt();
		System.out.println("enter end node: ");
		int end_node=ob.nextInt();
		T.dijkstra(graph,start_node,start_node,end_node);
	}
}
