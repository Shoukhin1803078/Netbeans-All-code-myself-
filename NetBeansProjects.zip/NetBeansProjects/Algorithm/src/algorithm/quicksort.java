package algorithm;

public class quicksort {
	
	static void Swap(int a[], int x, int y) {
		int temp = a[x];
		a[x] = a[y];
		a[y] = temp;
	}

	static int Partition(int a[], int lb, int ub) {
		int start = lb;
		int end = ub;
		int pivot = a[lb];
		while (start < end) {
			while (a[start] <= pivot) {
				start++;
			}
			while (a[end] > pivot) {
				end--;
			}
			if(start<end)
			{
			Swap(a,start,end);
			}
		}
		
			Swap(a,lb,end);
		return end;
	}

	static void QuickSort(int a[], int lb, int ub) {
		if (lb < ub) {
			int loc = Partition(a, lb, ub);
			QuickSort(a, lb, loc - 1);
			QuickSort(a, loc + 1, ub);
		}
	}

	public static void main(String[] args) {
		int a[] = {10, 5, 3, 1, 7, 15, 4, 20, 24};
		QuickSort(a, 0, a.length - 1);
		
		for (int i = 0; i < a.length; i++) {
			System.out.print(a[i]+" ");
		}
	}
}
