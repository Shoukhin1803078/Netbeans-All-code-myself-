/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algorithm;

import java.util.Scanner;

public class inputDataCreat {
	public static void main(String[] args) {
		Scanner ob=new Scanner(System.in);
		int n=ob.nextInt();
		for(int i=0;i<n;i++)
		{
			System.out.println(((int)(Math.random()*100000)+1)+" ");
		}
	}
}
