
package algorithm;
import java.util.Arrays;

public class NQueens {
	static int[] result; 

	public boolean Is_safe(int x2, int y2) {
		for (int i = 1; i < x2; i++) {
			if(result[i]==y2){
				
			return false;
			}
			else if ( (Math.abs(i - x2) == Math.abs(result[i] - y2))) {
				return false;
			}
		}
		return true;
	}
	public void placeQueens(int k, int size) {
		//System.out.println("for "+k+"th queen:");
		
		for (int col = 1; col <=size; col++) {
			System.out.println(col+" ");
			if (Is_safe(k, col)) {
				System.out.println(" "+col);
				result[k] = col; 
				if (k == size ) {
						System.out.print("Solution : ");
						for(int i=1;i<=size;i++){System.out.print(result[i]+" ");}
						System.out.println();
				}
				
				placeQueens(k + 1, size);
			}
			//else{
				//for(int i=0;i<result.length;i++){System.out.print(result[i]);}System.out.println();
				//System.out.print(" "+col+" ");
				//System.out.println();
				//System.out.println("Backtrack from : "+k);
				//System.out.println("Backtrack from : "+k);
			//}
		}
	}
	public static void main(String[] args) {
		int n = 4;
		result = new int[n+1];
		NQueens i = new NQueens();
		i.placeQueens(1, n);
	}
}