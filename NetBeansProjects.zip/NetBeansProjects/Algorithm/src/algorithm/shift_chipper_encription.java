/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algorithm;

import java.util.HashMap;
import java.util.Vector;

/**
 *
 * @author User
 */
public class shift_chipper_encription{

	public static void main(String[] args){
		
		//Encryption : f(p)=(p+k)%26; k=1803080+1803078
		
		char a[]={'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
		HashMap<Character,Integer> hs=new HashMap();
		HashMap<Integer,Character> hs1=new HashMap();
		for(int i=0;i<a.length;i++){
			hs.put(a[i],i);
			hs1.put(i,a[i]);
		}
		System.out.println(hs);
		String s="HAPPY BIRTH DAY MY DEAR BEST FRIEND LIFE IS JUST ABOUT TO PICK UP SPEED AND BLAST OFF INTO THE STRATOSPHERE WEAR A SEAT BELT TO ENJOY THE JOURNEY I WISH YOUR EVERY SINGLE DAY WOULD BE FILLED WITH SUNSHINE";
		//String s="T";
		Vector<String> v=new Vector();
		String s1[]=s.split(" ");
		//System.out.println(s.s);
		for(int i=0;i<s1.length;i++){
			//System.out.println(s1[i]);
			String x=s1[i];
			String s2="";
			for(int j=0;j<x.length();j++){
				//System.out.println(x.charAt(j)+"="+hs.get(x.charAt(j)));
				char y=x.charAt(j);
				int z=hs.get(y);
				z=(z+(1803080+1803078))%26;
				//System.out.println(z);
				s2+=hs1.get(z);
				System.out.print(hs1.get(z));
			}
			System.out.println();
			//System.out.println(s2);
			v.add(s2);
		}
		System.out.println(v);
		for(int i=0;i<v.size();i++)
		{
			System.out.print(v.get(i)+" ");
		}
		System.out.println();
		
		
		//Decryption 
		for(int i=0;i<v.size();i++){

			String s3=v.get(i);
			for(int j=0;j<s3.length();j++){

				char y=s3.charAt(j);
				int z=hs.get(y);
				z=(z-(1803080+1803078))%26;
				if(z<0){
					z=26+z;
				}
				//System.out.println(z);
				System.out.print(hs1.get(z));
			}
			//System.out.println();
			System.out.println();
			//v.add(s2);
		}
	}
}
