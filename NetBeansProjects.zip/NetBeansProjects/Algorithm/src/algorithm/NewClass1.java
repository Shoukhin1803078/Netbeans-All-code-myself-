/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algorithm;

import java.util.HashMap;


public class NewClass1 {
	public static void main(String[] args) {
		
				HashMap<Double ,Integer>hs=new HashMap();
				hs.put(1.333, 1);
				hs.put(5.6, 4);
				System.out.println(hs.get(1.333));
	}
	
}
