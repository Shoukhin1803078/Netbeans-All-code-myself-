/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algorithm;

public class dijkstra_myself{
	public static void main(String[] args){
		int v=6;
		int e=11;
		int cost [][]=new int [v+1][e+1];
		for(int i=0;i<v)
		
	}
}
