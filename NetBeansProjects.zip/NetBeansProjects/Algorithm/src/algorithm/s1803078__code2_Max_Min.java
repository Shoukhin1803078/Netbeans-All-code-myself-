
package algorithm;

import java.io.File;
import java.util.Scanner;

public class s1803078__code2_Max_Min {

	static long count = 0;
	static int max = Integer.MIN_VALUE;
	static int min = Integer.MIN_VALUE;
	static int a[];
	static int n;

	static void MaxMin(int i, int j) {
		int max1, min1, mid;

		if (i == j) {
			max = min = a[i];
		} else {

			if (i == j - 1) {
				count++;
				if (a[i] < a[j]) {
					max = a[j];
					min = a[i];
				} else {
					max = a[i];
					min = a[j];
				}
			} else {
				mid = (i + j) / 2;
				MaxMin(i, mid);

				max1 = max;
				min1 = min;
				MaxMin(mid + 1, j);
				count+=2;
				if (max < max1) {
					max = max1;
				}
				if (min > min1) {
					min = min1;
				}
			}
		}
	}

	public static void main(String[] args) {
		File f = new File("MaxMin1.txt");
		try {
			Scanner sc = new Scanner(f);
			while (sc.hasNext()) {
				n = Integer.valueOf(sc.next());
				a = new int[n];
				for (int i = 0; i < n; i++) {
					a[i] = Integer.valueOf(sc.next());
				}
			}
			MaxMin(0, n - 1);
			System.out.println("Max value: " + max + "\nMin value: " + min);
			System.out.println("Number of comparison: "+count);
		} catch (Exception e) {
			System.out.println("exception found");
		}
	}
}
