package algorithm;

import java.util.LinkedList;
import java.util.Scanner;

public class dijkstra_heap_1803078{

	static class Edge{

		int source;
		int destination;
		int weight;

		public Edge(int source,int destination,int weight){
			this.source=source;
			this.destination=destination;
			this.weight=weight;
		}
	}

	static class HeapNode{

		int vertex;
		int distance;
	}

	static class Graph{

		int vertices;
		LinkedList<Edge>[] adjacencylist;

		Graph(int vertices){
			this.vertices=vertices;
			adjacencylist=new LinkedList[vertices];
			for(int i=0;i<vertices;i++){
				adjacencylist[i]=new LinkedList<>();
			}
		}

		public void addEdge(int source,int destination,int weight){
			Edge edge=new Edge(source,destination,weight);
			adjacencylist[source].addFirst(edge);

			edge=new Edge(destination,source,weight);
			adjacencylist[destination].addFirst(edge); //for undirected graph
		}

		public void dijkstra_GetMinDistances(int sourceVertex,int end){
			int INFINITY=Integer.MAX_VALUE;
			boolean[] SPT=new boolean[vertices];

			HeapNode[] heapNodes=new HeapNode[vertices];
			for(int i=0;i<vertices;i++){
				heapNodes[i]=new HeapNode();
				heapNodes[i].vertex=i;
				heapNodes[i].distance=INFINITY;
			}

			heapNodes[sourceVertex].distance=0;

			MinHeap minHeap=new MinHeap(vertices);
			for(int i=0;i<vertices;i++){
				minHeap.insert(heapNodes[i]);
			}
			while(!minHeap.isEmpty()){

				HeapNode extractedNode=minHeap.extractMin();

				int extractedVertex=extractedNode.vertex;
				SPT[extractedVertex]=true;

				LinkedList<Edge> list=adjacencylist[extractedVertex];
				for(int i=0;i<list.size();i++){
					Edge edge=list.get(i);
					int destination=edge.destination;

					if(SPT[destination]==false){

						int newKey=heapNodes[extractedVertex].distance+edge.weight;
						int currentKey=heapNodes[destination].distance;
						if(currentKey>newKey){
							decreaseKey(minHeap,newKey,destination);
							heapNodes[destination].distance=newKey;
						}
					}
				}
			}

			printDijkstra(heapNodes,sourceVertex,end);
		}

		public void decreaseKey(MinHeap minHeap,int newKey,int vertex){

			int index=minHeap.indexes[vertex];

			HeapNode node=minHeap.mH[index];
			node.distance=newKey;
			minHeap.bubbleUp(index);
		}

		public void printDijkstra(HeapNode[] resultSet,int sourceVertex,int end){
			System.out.println("Smallest distance from  Vertex: "+(sourceVertex+1)+" to vertex "+end+" distance: "+resultSet[end-1].distance);

		}
	}

	static class MinHeap{

		int capacity;
		int currentSize;
		HeapNode[] mH;
		int[] indexes;

		public MinHeap(int capacity){
			this.capacity=capacity;
			mH=new HeapNode[capacity+1];
			indexes=new int[capacity];
			mH[0]=new HeapNode();
			mH[0].distance=Integer.MIN_VALUE;
			mH[0].vertex=-1;
			currentSize=0;
		}

		public void insert(HeapNode x){
			currentSize++;
			int idx=currentSize;
			mH[idx]=x;
			indexes[x.vertex]=idx;
			bubbleUp(idx);
		}

		public void bubbleUp(int pos){
			int parentIdx=pos/2;
			int currentIdx=pos;
			while(currentIdx>0&&mH[parentIdx].distance>mH[currentIdx].distance){
				HeapNode currentNode=mH[currentIdx];
				HeapNode parentNode=mH[parentIdx];

				indexes[currentNode.vertex]=parentIdx;
				indexes[parentNode.vertex]=currentIdx;
				swap(currentIdx,parentIdx);
				currentIdx=parentIdx;
				parentIdx=parentIdx/2;
			}
		}

		public HeapNode extractMin(){
			HeapNode min=mH[1];
			HeapNode lastNode=mH[currentSize];

			indexes[lastNode.vertex]=1;
			mH[1]=lastNode;
			mH[currentSize]=null;
			sinkDown(1);
			currentSize--;
			return min;
		}

		public void sinkDown(int k){
			int smallest=k;
			int leftChildIdx=2*k;
			int rightChildIdx=2*k+1;
			if(leftChildIdx<heapSize()&&mH[smallest].distance>mH[leftChildIdx].distance){
				smallest=leftChildIdx;
			}
			if(rightChildIdx<heapSize()&&mH[smallest].distance>mH[rightChildIdx].distance){
				smallest=rightChildIdx;
			}
			if(smallest!=k){

				HeapNode smallestNode=mH[smallest];
				HeapNode kNode=mH[k];

				indexes[smallestNode.vertex]=k;
				indexes[kNode.vertex]=smallest;
				swap(k,smallest);
				sinkDown(smallest);
			}
		}

		public void swap(int a,int b){
			HeapNode temp=mH[a];
			mH[a]=mH[b];
			mH[b]=temp;
		}

		public boolean isEmpty(){
			return currentSize==0;
		}

		public int heapSize(){
			return currentSize;
		}
	}

	public static void main(String[] args){
		Scanner ob=new Scanner(System.in);

		int v=ob.nextInt();
		int e=ob.nextInt();
		Graph graph=new Graph(v);
		for(int i=0;i<e;i++){
			int u1=ob.nextInt();
			int v1=ob.nextInt();
			int c=ob.nextInt();
			graph.addEdge(u1-1,v1-1,c);
		}
		System.out.println("Enter start node: ");
		int start=ob.nextInt();
		System.out.println("Enter end node: ");
		int end=ob.nextInt();

		//long t1=System.nanoTime();
		double t11=System.currentTimeMillis();
		
		graph.dijkstra_GetMinDistances(start-1,end);
		double  t22=System.currentTimeMillis();
		//long t2=System.nanoTime();
		System.out.println("Time take : "+(t22-t11)+" mili sec");

	}
}
