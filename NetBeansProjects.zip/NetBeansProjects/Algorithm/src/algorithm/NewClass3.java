/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algorithm;


public class NewClass3{
	public static void main(String[] args){
	 int a[]=new int[100];
	 int b []=new int[100];
	 int c[]=new int[100];
	 System.out.println("100 100");
	
		 System.out.println((Math.random()*200)+200); 
	 
	}
}
