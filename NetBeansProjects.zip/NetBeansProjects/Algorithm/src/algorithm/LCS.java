package algorithm;

import java.util.Scanner;

public class LCS{
	public static void main(String[] args){
		Scanner ob=new Scanner(System.in);
		String A=ob.next();
		String B=ob.next();
		int m=A.length(), n=B.length();
		int[][] ans=new int[m+1][n+1];
		for(int i=0;i<m;i++){
			ans[i][0]=0;

		}
		for(int j=0;j<n;j++){
			ans[0][j]=0;

		}
		for(int i=1;i<=m;i++){
			for(int j=1;j<=n;j++){
				if(A.charAt(i-1)==B.charAt(j-1)){
					ans[i][j]=ans[i-1][j-1]+1;
				}else{
					ans[i][j]=Math.max(ans[i-1][j],ans[i][j-1]);
				}
			}
		}
		System.out.println(ans[m][n]);
	}
}
