package codeforces;
///*بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيم*///

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Vector;
//import javafx.util.Pair;

public class NewClass{

	/*	static class House{

		long x;
		long y;
		int i;

		public House(long x,long y,int i){
			this.x=x;
			this.y=y;
			this.i=i;
		}
	}

	static long mod=1000000007;
	static int n11=100000;
	static boolean a11[]=new boolean[n11+1];
	static Vector<Long> v11=new Vector();

	static long gcd(long a,long b){
		if(b==0){
			return a;
		}
		return gcd(b,a%b);
	}

	static void seive(){
		//a=new boolean[n+1];
		for(int i=0;i<n11;i++){
			a11[i]=true;
		}

		for(int i=2;i<Math.sqrt(n11);i++){
			if(a11[i]==true){
				for(int j=i*i;j<=n11;j+=i){
					a11[j]=false;
				}
			}
		}

		for(int i=2;i<n11;i++){
			if(a11[i]==true){
				v11.add((long) i);
			}
		}
		//System.out.println(v.size());
	}
	 */
	public static void main(String[] args){
Scanner ob=new Scanner(System.in);
		//int a[]={1,2,3,4,5,6};
		
		long n=ob.nextLong();
		int ans=0;
		for(int i=0;i<120;i++)
		{
		if(Math.pow(2,i)>=n)
		{
		ans=i;break;
		}
		}
		ans--;
		System.out.print("A");
		for(int i=0;i<ans;i++){
			System.out.print("B");
		}
		for(int i=0;i<(n-Math.pow(2,ans));i++)
		{
			System.out.print("A");
		}
		System.out.println();
		//System.out.println(gcd(876043,28));
		//System.out.println(gcd((long)Math.pow(10, 18),(long)Math.pow(10, 18)+1));
		//Scanner fs = new Scanner(System.in);
		//HashMap<Integer,Integer> hs=new HashMap();
		//HashSet<Integer> h = new HashSet();
		//Vector<Integer> v = new Vector();
		//Vector<Pair<Integer, Integer>> vp = new Vector();
		//int t = fs.nextInt();
		//while (t-- > 0) {
	/*	Scanner ob=new Scanner(System.in);
		int t=ob.nextInt();
		for(int ii=0;ii<t;ii++){
			//HashMap<Character,Integer>hs=new HashMap();
			long n=ob.nextLong();
			//int a[]=new int[n];
			long a=(long) Math.ceil(n*1.0/6);
			long b=(long) Math.ceil(n*1.0/8);
			long c=(long) Math.ceil(n*1.0/10);
			//BigDecimal a1=BigDecimal.valueOf(a);
			//	BigDecimal b1=BigDecimal.valueOf(b);
			//BigDecimal c1=BigDecimal.valueOf(c);
			//BigDecimal a11=a1.multiply(BigDecimal.valueOf(15));
			//BigDecimal b11=b1.multiply(BigDecimal.valueOf(20));
			//BigDecimal c11=c1.multiply(BigDecimal.valueOf(25));
			//System.out.println(a11.min(b11.min(c11)));

			//System.out.println(a1.min(b1));
			long ans1=a*15;
			long ans2=b*20;
			long ans3=c*25;
			//System.out.println(ans1+" "+ans2+" "+ans3);			
//long a=(int)Math.ceil(n*1.0/6);
			long ans=Math.min(a*15,Math.min(b*20,c*25));
			System.out.println(a+" "+b+" "+c);
			//System.out.println(ans);
			int k1=0;
			int k2=0;
			for(int i=0;i<=c;i++){
				for(int j=0;j<=b;j++){
					for(int k=0;k<=a;k++){
						if(i*25+j*20+k*15>=n)
						{
							ans=Math.min(ans,i*25+j*20+k*15);
							//System.out.println();
							k1=1;
							break;
						}
						
					}
					if(k1==1){
						k2=1;
					break;
					}
				}
				if(k2==1)
				{
				break;
				}
			}
			System.out.println(ans);
*/
			//System.out.println(v);
			//System.out.println(hs);
			//.out.println((int)Math.ceil(s.length()*1.0/hs.size()));
			/*System.out.println(hs);
			int k=0;
			if(s.length()==1){
				System.out.println("0");
			}else{
				{
					for(int i=1;i<s.length();i++){
						if(s.charAt(i)!=s.charAt(0)){
							k++;
							break;
						}
					}
				}
				if(k==1){
					int x=s.length()/2;
					System.out.println(x);
				}else{
					System.out.println("1");
				}
			}
			 */
			//System.out.println();
			/*Vector<Integer> v = new Vector();
		for(int i=0;i<n1;i++)
		{
		for(int j=i+1;j<n1;j++)
		{
			v.add(Math.max(Math.abs(a[i]-a[j]),Math.abs(b[i]-b[j])));
		//v.add(Math.max(Math.abs(vp.get(i).getKey()-vp.get(j).getKey()),Math.abs(vp.get(i).getValue()-vp.get(j).getValue())));
		}
		}
		
		Collections.sort(v,Collections.reverseOrder());
		//System.out.println(v);
		System.out.println(v.get(1));
			 */
			//System.out.println(v);
			//long sum=1;
			//    long two=2;
			//    long six=6;
			//   long one=1;
			// double sum=(n/2)(2a+(n-1)*d)  +  1  ;
			//BigDecimal b=BigDecimal.valueOf(sum);
			// BigDecimal t=BigDecimal.valueOf(two);
			// System.out.println(sum);
			//for(int i=2;i<=10;i++)
			//{
			//sum*=i;
			//}
			//System.out.println(sum);
			//for(long i=0;i<=n;i+=2520)
			//	{
			//if(i%2==0&&i%3==0&&i%4==0&&i%5==0&&i%6==0&&i%7==0&&i%8==0&&i%9==0&&i%10==0)
			//{
			//	System.out.println(i);
			//}
			//}
			//System.out.println(n%2==0?"2":"1");
		}
	}
//}
