package codeforces;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Vector;

public class Solution{

	static long gcd(long a,long b){
		if(b==0){
			return a;
		}
		return gcd(b,a%b);
	}

	public static void main(String[] args){
		
		Scanner ob=new Scanner(System.in);
		int t=ob.nextInt();
		out:for(int ii=0;ii<t;ii++){
			int n=ob.nextInt();
			int x=n%7;
			int y=7-x;
			int last_digit=n%10;
			
			if(n%7==0){System.out.println(n);}
			else{
			
			}

		}

	}
}
