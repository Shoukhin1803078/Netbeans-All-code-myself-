package codeforces;

import java.util.*;

public class NewClass_1656_B{

	public static void main(String[] args){
		Scanner ob=new Scanner(System.in);
		int t=ob.nextInt();
		out:
		for(int ii=0;ii<t;ii++){
			int n=ob.nextInt();
			int k=ob.nextInt();
			int a[]=new int[n];
			Map<Integer,Integer> mp=new HashMap();
			for(int i=0;i<n;i++){
				a[i]=ob.nextInt();
				mp.put(a[i],1);
			}
			for(int i=0;i<n;i++){
				if(mp.get(a[i]+k).equals(1)){
					System.out.println("YES");
					continue out;
				}
				else{
				mp.put(a[i]+k,1);
				}
			}
			System.out.println("NO");
		}
	}
}
