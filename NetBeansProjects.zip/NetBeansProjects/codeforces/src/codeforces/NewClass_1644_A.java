/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codeforces;

import java.util.*;

public class NewClass_1644_A{

	public static void main(String arg[]){
		Scanner ob=new Scanner(System.in);
		int tt=ob.nextInt();
		out:
		for(int t=0;t<tt;t++){
			String s=ob.next();
			HashSet<Character> hs=new HashSet();
			for(int i=0;i<s.length();i++){
				hs.add(s.charAt(i));
				if(s.charAt(i)=='R'){
					if(!hs.contains('r')){
						System.out.println("NO");
						continue out;
					}
				}
				if(s.charAt(i)=='G'){
					if(!hs.contains('g')){
						System.out.println("NO");
						continue out;
					}
				}
				if(s.charAt(i)=='B'){
					if(!hs.contains('b')){
						System.out.println("NO");
						continue out;
					}
				}
			}
			System.out.println("YES");

		}
	}
}
