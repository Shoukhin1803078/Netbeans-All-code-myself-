/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codeforces;

/**
 *
 * @author User
 */
public class NewClass4 {

	static int partition(int array[], int lb, int ub) {
		int pivot = array[lb];
		int i = lb;
		int j = ub;
		//int temp;
		while (i < j) {
			
			while ( array[i]<=pivot) {
				i++;
			}
			while (pivot < array[j]) {
				j--;
			}
			//if (i < j) {
				int temp = array[i];
				array[i] = array[j];
				array[j] = temp;
			//}
		} 
		return j;           // middle  
	}

	static void QuickSort(int num[], int too_big_index, int too_small_index) {
		// too_big_index =  beginning of array
		// too_small_index = end of array

		int middle;
		if (too_big_index < too_small_index) {
			middle = partition(num, too_big_index, too_small_index);
			QuickSort(num, too_big_index, middle);   // sort first section
			QuickSort(num, middle + 1, too_small_index);    // sort second section
		}
		return;
	}

	public static void main(String[] args) {
		int arr[] = {8,7,13, 8, 5, 19, 1, 40, 12, 34};

		QuickSort(arr, 0,9);
		for (int i = 0; i < 10; i++) {
			System.out.println(arr[i]);
		}
	}
}