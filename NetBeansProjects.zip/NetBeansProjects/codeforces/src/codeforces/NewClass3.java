/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codeforces;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Vector;

public class NewClass3 {

	static int n11 = 1000000;
	static Vector<Integer> v11 = new Vector();
	static boolean a11[] = new boolean[1000000 + 500];

	static void generatePrime() {

		for (int i = 2; i * i <= n11; i++) {
			if (a11[i] == false) {
				for (int j = i * i; j <= n11; j += i) {
					a11[j] = true;
				}
			}
		}
		for (int i = 2; i <= n11; i++) {
			if (a11[i] == false) {
				v11.add(i);
			}
		}
		//System.out.println(v);
	}

	static int gcd(int a, int b) {
		if (b == 0) {
			return a;
		}
		return gcd(b, a % b);
	}

	public static void main(String[] args) {
		Scanner fs = new Scanner(System.in);
		int t = fs.nextInt();
		out:
		for (int tt = 0; tt < t; tt++) {

			String s = fs.next();
			long k = 0;
			int pos = 0;
			char c = 'a';
			for (int i = 0; i < s.length(); i++) {
				if (s.charAt(i) != 'a') {
					pos = i;
					k++;
				}
			}
			//System.out.println(k);
			if (k != 0) {
				System.out.println("YES");
				if (pos <= (s.length() - 1) / 2) {
					for (int i = 0; i < s.length(); i++) {
						{
							
							{System.out.print(s.charAt(i));}
							
						}
					}
					System.out.println("a");
					
					System.out.println();
				} else {
					System.out.print("a");
					for (int i = 0; i < s.length(); i++) {
						{
							if(i==(s.length()-1)/2)
							{
								
								System.out.print(s.charAt(i));
								
							}
							else{System.out.print(s.charAt(i));}
							
						}
					}
					System.out.println();
				}
			} else {
				System.out.println("NO");
			}
			//System.out.println("NO");

		}

	}
}
