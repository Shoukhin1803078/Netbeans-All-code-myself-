package codeforces;

import java.util.Arrays;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.Stack;
import java.util.Vector;
//import javafx.util.Pair;

public class NewClass1{

	public static void main(String[] args){
		//System.out.println(gcd(876043,28));
		//System.out.println(gcd((long)Math.pow(10, 18),(long)Math.pow(10, 18)+1));
		//HashMap<Integer, String> hs = new HashMap();
		//HashSet<Integer> h = new HashSet();
		//Vector<Integer> v = new Vector();
		//Vector<Pair<Integer, Integer>> vp = new Vector();
		Scanner ob=new Scanner(System.in);
		int t=ob.nextInt();
		out:
		while(t-->0){
			int x=ob.nextInt();
			HashMap<Integer,Integer> hs=new HashMap();
x++;
			for(int i=1;i<x;i++){
				hs.put(ob.nextInt(),i);
			}
			int x1=ob.nextInt();
			int a[]=new int[x1];
			for(int i=0;i<x1;i++){
				a[i]=ob.nextInt();
			}
		           for(int i=0;i<x1;i++){
					   int b=a[i];
				for(Map.Entry<Integer,Integer> entry:hs.entrySet()){
					
					if(entry.getValue()!)
				int  key=entry.getKey();
				if(key!=b){
				
				}
				int value=entry.getValue();
			}
			}
			

		}

	}
}
