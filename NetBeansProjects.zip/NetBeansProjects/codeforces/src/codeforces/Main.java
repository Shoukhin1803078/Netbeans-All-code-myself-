package codeforces;
///-----------*بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيم*------------///

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Scanner;
import java.util.Set;
import java.util.Vector;

public class Main{

	static class Pair{

		int x;
		int y;

		Pair(int x1,int y1){
			x=x1;
			y=y1;
		}
	}

	static long gcd(long a,long b){
		if(b==0){
			return a;
		}
		return gcd(b,a%b);
	}

	static long bigmod(int a,int b,int M){
		long ans=1;
		long reminder=a%M;
		while(b!=0){
			if(b%2==1){
				ans=(ans*reminder)%M;
			}
			reminder=(reminder*reminder)%M;
			b/=2;
		}
		return ans;
	}

	public static void main(String[] args){
		Scanner ob=new Scanner(System.in);
		int t=ob.nextInt();
		for(int ii=0;ii<t;ii++){
			int x=ob.nextInt();
			int y=x;
			String s1=String.valueOf(x);
			String ans="";
			for(int i=0;i<s1.length();i++){
				ans+="7";
			}
			
			for(int i=1;i<Integer.MAX_VALUE;i++){
				if(x%7==0){
					break;
				}else{
					x--;
				}
			}
			for(int i=1;i<Integer.MAX_VALUE;i++){
				if(y%7==0){
					break;
				}else{
					y++;
				}
			}
			String s3=String.valueOf(x);
			String s4=String.valueOf(y);

			if(s3.length()==s4.length()){
				int m=0;
				int n=0;
				for(int i=0;i<s1.length();i++){
					if(s3.charAt(i)!=s1.charAt(i)){
						m++;
					}
				}
				for(int i=0;i<s1.length();i++){
					if(s4.charAt(i)!=s1.charAt(i)){
						n++;
					}
				}
				if(m>n){
					System.out.println(s4);
				}else{
					System.out.println(s3);
				}
			}else if(s3.length()<s4.length()){
				System.out.println(s3);
			}else{
				System.out.println(s4);
			}

		}

		//int a[]={1,2,3,4,5,6};
		//System.out.println(count);
		//System.out.println(count);
		/*while(B!=0){
			for(int i=a.length-1;i>=0;i--){
				while(B>=a[i])
				{
				B-=a[i];
					System.out.println(B);
				count++;
				}
			}
		}
		if(B<0){System.out.println("No");System.exit(0);}
		if(count==A)
		{
			System.out.println("Yes");
		}
		else{System.out.println("No");}
		System.out.println(count);
		 */
		//int t=ob.nextInt();
		/*while(t-->0){
			int n=ob.nextInt();
			HashMap<Integer,Integer> hs=new HashMap();
			HashMap<Integer,Integer> hs1=new HashMap();
			int a[]=new int[n];
			for(int i=0;i<n;i++){
				int x=ob.nextInt();
				a[i]=x;
				hs.put(x,hs.getOrDefault(x,0)+1);
			}
			int m=0;
			
			
			int count=0;
			long sum=0;
			System.out.println(hs);
			for(Map.Entry<Integer,Integer> e:hs.entrySet()){
				int x=e.getValue();
				sum+=x;
			}
			int ans=0;
			int curr=0;
			for(Map.Entry<Integer,Integer> e:hs.entrySet()){
			int x=e.getValue();
			ans+=curr*x;
			curr=curr+x;
			}
			System.out.println(ans);
			
		}
		 */
 /*	
		int a[]=new int[4];
			a[0]=ob.nextInt();
			a[1]=ob.nextInt();
			a[2]=ob.nextInt();
			a[3]=ob.nextInt();
			int x=Math.max(a[0],a[1]);
			int y=Math.max(a[2],a[3]);
			Arrays.sort(a);
			if((a[a.length-1]+a[a.length-2])==(x+y)){System.out.println("YES");}
			else{
				System.out.println("NO");
			}
		}
		 */
		//System.out.println(sum);
		//System.out.println(2&1);
		//Vector<Pair> v=new Vector();
		//out:
		//while(t-->0){
		//int x=ob.nextInt();
		//int y=ob.nextInt();
		//Pair p=new Pair(x,y);
//v.add(p);
		//Map<Integer,Integer> hs1=new HashMap();
		//HashMap<Integer,Integer>hs2=new HashMap();
		//HashMap<Integer,Integer>hs3=new HashMap();
		/*Vector<Integer> v[]=new Vector[t+1];
			int a[]=new int[t];
			int b[]=new int[t];
			int c[]=new int[t];
 
			int count[]=new int[t+1];
			for(int i=0;i<t;i++){
				a[i]=ob.nextInt();
			}
			for(int i=0;i<t;i++){
				b[i]=ob.nextInt();
			}
			for(int i=0;i<t;i++){
				c[i]=ob.nextInt();
			}
 
			HashMap<Integer,Integer> map=new HashMap<>();
			for(int i=0;i<t;i++){
				map.put(b[c[i]-1],map.getOrDefault(b[c[i]-1],0)+1);
			}
			System.out.println(map);
			//System.out.println(count);
			long ans=0;
			for(int i=0;i<t;i++){
				ans+=a[i];
			}
			System.out.println(ans);*/
		//Vector<Integer>v=new Vector();
		//String s=ob.next();
		//long n=ob.nextLong();
		/*String s1="";
			for(int i=0;i<s.length();i++)
			{
			s1+='1';
			}
			//long x=(n1/Integer.parseInt(s1))*Integer.parseInt(s1);
			//n1-=Integer.parseInt(s1);
			 
			//System.out.println(x);
		 */
		//System.out.println(n1);
		//System.out.println("NO");
		/*
			for(int i=a.length-1;i>=0;i--){
				System.out.println(n);
 
				if(n%a[i]==0){
					System.out.println("YES");
					continue out;
				}
				//long q=n/a[i];
				n-=(a[i]);
				{
					for(int j=i;j>=0;j--){
 
						if(n%a[j]==0){
							System.out.println("YES");
							continue out;
						}
						long q=n/a[j];
						n-=(a[i]);
 
					}
				}
			}
			System.out.println(n);
			System.out.println("NO");
		 */
		//
		//System.out.println(count+1);
		//Arrays.sort(a);
		//Collections.sort(v);
		//for(int i=0;i<n;i++)
		//{
		//if(a[i]>a[0])
		//{
		//count++;
		//}
		//}
		//System.out.println(hs.size());
		//System.out.println(hs1);
		//
		//int max=0;
		//for(Map.Entry<Integer,Integer>e:hs1.entrySet())
		//{
		//max=Math.max(max,e.getValue());
		//v.add(e.getValue());
		//}
		//Collections.sort(v);
		//System.out.println(v.get(0));
		//System.out.println(a.length-v.get(v.size()-1));
		//int x=v.get(0);
		//	System.out.println(a.length-max);
		//}
		//System.out.println(v);
	}
}
