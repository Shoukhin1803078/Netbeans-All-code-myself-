/*
 * To change this license header, choose License Headers in Project Properties	.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codeforces;

import java.util.*;
import java.io.*;

public class NewClass_339B{

	public static void main(String[] args){
		Scanner ob=new Scanner(System.in);
		int n=ob.nextInt();
		int m=ob.nextInt();
		int a[]=new int[m];
		for(int i=0;i<m;i++){
			a[i]=ob.nextInt();
		}
		int x=a[0];
		long count=x-1;
		for(int i=1;i<m;i++){
			int y=a[i];
			if(x==y){
			}else if(x>y){
				count++;
				count+=(y-1);
				count+=(n-x);
			}else{
				count+=(y-x);
			}
			x=y;
		}
		System.out.println(count);
	}
}
