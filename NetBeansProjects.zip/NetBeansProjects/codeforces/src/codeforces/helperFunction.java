/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codeforces;

import java.util.HashMap;
import java.util.Vector;

public class helperFunction{

	static long mod=1000000007;

	class Pair{

		int a, b;

		Pair(int a,int b){
			this.a=a;
			this.b=b;
		}
	}

	static long fac(int p){
		if(p==0||p==1){
			return 1;
		}
		return p*fac(p-1);
	}

	public static HashMap<Integer,Integer> primefac(int n){
		HashMap<Integer,Integer> hm=new HashMap<>();
		//int x = (int) Math.sqrt(n);
		for(int i=2;i<=n;i++){
			int x=0;
			while(n%i==0){
				n=n/i;
				++x;
			}
			if(x!=0){
				hm.put(i,x);
			}
		}
		return hm;
	}

	static class Clock{

		protected long start, stop;

		public void start(){
			start=System.currentTimeMillis();
		}

		public void stop(){
			stop=System.currentTimeMillis();
		}

		public String getTime(){
			return ((stop-start)+" ms");
		}
	}

	static long powmodulo(long a,long p){
		if(p==0){
			return 1%mod;
		}
		if(p==1){
			return a%mod;
		}
		long ans=1;
		while(p>0){
			if((p&1)>0){
				ans=(ans*a)%mod;
			}
			a=(a*a)%mod;
			p=p>>1;
		}
		return ans%mod;
	}
	public static int arr[];

	static void seive(int n){
		// 1 is not prime
		arr=new int[n+1];
		arr[0]=arr[1]=1;
		for(int i=4;i<=n;i=i+2){
			arr[i]=1;
		}
		for(int i=3;i*i<=n;i=i+2){
			if(arr[i]==0){
				for(int j=i*i;j<=n;j=j+i){
					arr[j]=1;
				}

			}
		}
	}
	public static void main(String[] args){
		//Vector<Pair<Integer,Integer>>v=new Vector();
	}

}
