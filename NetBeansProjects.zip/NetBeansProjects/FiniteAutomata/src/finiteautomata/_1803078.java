
package finiteautomata;

import java.util.Scanner;
import java.util.Stack;
import java.util.Vector;

public class _1803078{

	static boolean isValid(String s1){
		String s=s1;
		if(s.contains("(")||s.contains(")")){
			//System.out.println(s);
			Stack<Character> st1=new Stack();
			Stack<Character> st2=new Stack();
			Vector<Character> v=new Vector();
			boolean k=true;
			for(int i=0;i<s.length();i++){
				char c=s.charAt(i);
				if(i==0&&(c=='*'||c=='+')){
					return false;
				}
				if((c=='*'||c=='+'||c=='('||c==')')){
					st1.add(c);
					v.add(c);
				}else if((c=='a'||c=='b'||c=='0'||c=='1')){
					st1.add('E');
					v.add(c);
				}else{
					k=false;
					break;
				}
			}

			for(int i=0;i<s.length();i++){
				char c1=s.charAt(i);
				if(c1=='('){
					st2.push(c1);
				}else if(c1==')'&&(st2.isEmpty()||st2.pop()!='(')){
					return false;
				}
			}

			if(k==false){
				return false;
			}

		}else{
			Vector<Character> v=new Vector();
			Stack<Character> st=new Stack();
			boolean k=true;
			for(int i=0;i<s.length();i++){
				char c=s.charAt(i);
				if(i==0&&(c=='*'||c=='+')){
					return false;
				}

				if(c=='*'||c=='+'){
					st.push(c);
					v.add(c);

				}else if((c=='a'||c=='b'||c=='0'||c=='1')){
					st.push('E');
					v.add(c);
					
				}else{
					k=false;
				}
			}
			if(k==false){
				return false;
				
			}else{
				//System.out.println(st);

				char pre=st.peek();

				while(!st.isEmpty()){
					st.pop();
					if(st.isEmpty()){
						break;
					}
					char c=st.peek();
					if((c=='+'||c=='*')&&(pre=='*'||pre=='+')){
						return false;

						//System.exit(0);
					}
					pre=c;
					//System.out.println(st.pop());
				}
				//System.out.println(v);
				
				return true;
			}
		}
		return true;
	}

	public static void main(String[] args){
		Scanner ob=new Scanner(System.in);
		System.out.println("Input: ");
		System.out.print("Please Enter a String : ");
		String ss=ob.next();
		boolean ans=isValid(ss);
		if(ans==false){
			System.out.println("Output:");
			System.out.println("It is not accepted by the grammar ");
		}else{
			System.out.println("Output:");
			System.out.println("It is accepted by the grammar");
		}
		//System.out.println();
		while(true){
			System.out.println();
			System.out.print("Do you want to continue ?(Y/N) :");
			String inp=ob.next();
			if(inp.equals("Y")){
				System.out.println("Input: ");
				System.out.print("Please Enter a String : ");
				String sss=ob.next();
				boolean ans1=isValid(sss);
				if(ans1==false){
					System.out.println("Output:");
					System.out.println("It is not accepted by the grammar ");
				}else{
					System.out.println("Output:");
					System.out.println("It is accepted by the grammar");
				}
			}else{	
				break;
			}
		}

	}
}
