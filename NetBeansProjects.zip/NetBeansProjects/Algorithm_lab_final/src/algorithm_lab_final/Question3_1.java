
package algorithm_lab_final;

import java.io.File;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Vector;

public class Question3_1{

	public static void main(String[] args){

		Scanner ob=new Scanner(System.in);

		{
			System.out.println("Enter capcity:");

			int capacity=ob.nextInt();
			Vector<Double> v=new Vector();
			HashMap<Double,Integer> FractionalAmount=new HashMap();
			Vector<Integer> fractionalVector=new Vector();
			HashMap<Double,Integer> hp=new HashMap();
			HashMap<Double,Integer> hw=new HashMap();
			System.out.println("Enter weight of that 5 object :");
			int w[]=new int[5];
			for(int ii=0;ii<5;ii++){
				w[ii]=ob.nextInt();
			}
			System.out.println("Enter values or profit of that 5 object :");
			int p[]=new int[5];
			for(int ii=0;ii<5;ii++){
				p[ii]=ob.nextInt();
			}
			for(int ii=0;ii<5;ii++){

				double rate=p[ii]*1.0/w[ii];
				hp.put(rate,p[ii]);
				hw.put(rate,w[ii]);
				FractionalAmount.put(rate,ii+1);
				v.add(rate);
			}
	
			Collections.sort(v,Collections.reverseOrder());

			//System.out.println(hp);
			//System.out.println(hw);
			int weight=0;
			double TotalProfit=0;
			int i=0;
			while(weight+hw.get(v.get(i))<capacity){
				weight+=hw.get(v.get(i));
				TotalProfit+=hp.get(v.get(i));
				fractionalVector.add(FractionalAmount.get(v.get(i)));
				i++;
			}
			int last_weight=hw.get(v.get(i));

			int baki_weight=capacity-weight;

			double lastfraction=baki_weight*1.0/last_weight;
			TotalProfit+=lastfraction*hp.get(v.get(i));
			weight+=lastfraction*hw.get(v.get(i));
			int last_object=FractionalAmount.get(v.get(i));
			System.out.print("tatal profit:"+TotalProfit);
			System.out.println();
			

			
		}
		
	}
}
