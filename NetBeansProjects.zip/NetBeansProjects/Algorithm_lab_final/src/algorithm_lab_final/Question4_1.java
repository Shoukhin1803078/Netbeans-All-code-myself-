
package algorithm_lab_final;

import java.io.File;
import java.util.Scanner;

public class Question4_1{

	public static void main(String[] args){
		try{
			File f=new File("input.txt");
			Scanner ob=new Scanner(f);
			int n=ob.nextInt();
			int a[]=new int[n];
			for(int i=0;i<n;i++){
				a[i]=ob.nextInt();
			}
			
			long t1=System.currentTimeMillis();
			for(int i=0;i<n;i++){
				for(int j=0;j<n-i-1;j++){
					if(a[j]>a[j+1]){
						int temp=a[j];
						a[j]=a[j+1];
						a[j+1]=temp;
					}
				}
			}
			long t2=System.currentTimeMillis();
			
			
			System.out.println("Number of elements in file:"+a.length);
			System.out.println("Sorted array:");
			for(int i=0;i<a.length;i++){
				System.out.print(a[i]+" ");
			}
			System.out.println("\n");
			System.out.println("Time count : "+(t2-t1)+" mili sec.\n");

		}catch(Exception e){
			System.out.println("Exception peyesi");
		}
	}
}