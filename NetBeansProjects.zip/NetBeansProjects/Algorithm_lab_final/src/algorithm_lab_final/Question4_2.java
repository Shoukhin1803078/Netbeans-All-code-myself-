
package algorithm_lab_final;

import java.io.File;
import java.util.Scanner;


public class Question4_2{
	public static void main(String[] args){
		try{
			File f=new File("input.txt");
			Scanner ob=new Scanner(f);
			int n=ob.nextInt();
			int a[]=new int[n];
			int max=Integer.MIN_VALUE;
			for(int i=0;i<n;i++){
				a[i]=ob.nextInt();
				max=Math.max(max,a[i]);
				//System.out.println(a[i]);
			}
			
			long start_time=System.currentTimeMillis();
			
			int b[]=new int[max+1];
			for(int i=0;i<a.length;i++){
				b[a[i]]++;
			}
			for(int i=1;i<b.length;i++){
				b[i]=b[i]+b[i-1];
			}
	
			int sorted_array[]=new int[b[b.length-1]];
			for(int i=0;i<a.length;i++){
				int pos=b[a[i]];
				sorted_array[pos-1]=a[i];
				b[a[i]]--;
			}
			
			long stop_time=System.currentTimeMillis();
			
			System.out.println("Number of elements in file : "+n);
			System.out.println("Sorted array is: ");
			for(int i=0;i<sorted_array.length;i++){
				System.out.print(sorted_array[i]+" ");
			}
			System.out.println();
			
			System.out.println("time count : "+(stop_time-start_time)+" mili sec");
			
			
			
		}catch(Exception e){
			System.out.println("Exception peyesi");
		}

	}
}
