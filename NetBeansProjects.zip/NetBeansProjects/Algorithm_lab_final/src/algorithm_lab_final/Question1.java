
package algorithm_lab_final;

import java.io.File;
import java.util.Scanner;

public class Question1{
	static int partition(int arr[],int l,int h){
		int p=arr[h];
		int i=(l-1);
		for(int j=l;j<h;j++){
			if(arr[j]<=p){
				i++;
				int temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
			}
		}
		int temp=arr[i+1];
		arr[i+1]=arr[h];
		arr[h]=temp;

		return i+1;
	}

	static void quicksort(int arr[],int l,int h){
		if(l<h){
			int pi=partition(arr,l,h);
			quicksort(arr,l,pi-1);
			quicksort(arr,pi+1,h);
		}
	}
	
	public static void main(String[] args){
		
		File f=new File("quick1.txt");
		try{
			Scanner sc1=new Scanner(f);
			int b[];
			while(sc1.hasNext()){
				String s=sc1.nextLine();
				int n1=Integer.valueOf(s);
				b=new int[n1];
				for(int i=0;i<n1;i++){
					b[i]=Integer.valueOf(sc1.next());
				}
				System.out.println("Number of Data: "+b.length);
				
				long t1=System.currentTimeMillis();
				quicksort(b,0,n1-1);
				long t2=System.currentTimeMillis();
				
				System.out.println("Sorted Array: ");
				for(int i=0;i<n1;i++){
					System.out.print(b[i]+" ");
				}
				
				System.out.println("\ntime take: "+(t2-t1)+" milisecond");
			}
		}catch(Exception e){
			System.out.println("Exceptions found");
		}
	}
}