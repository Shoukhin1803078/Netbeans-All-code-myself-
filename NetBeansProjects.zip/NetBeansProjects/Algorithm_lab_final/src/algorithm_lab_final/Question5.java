
package algorithm_lab_final;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;
import java.util.Vector;


public class Question5{
	
static int visited[];
static Vector <Integer> v[];
	public static void main(String[] args){
		Scanner ob=new Scanner(System.in);
		System.out.print("Enter the number of vertices : ");
		int node=ob.nextInt();
		
		visited=new int[node+1];
		v=new Vector[node+1];
		
		
		int a[][]=new int[node+1][node+1];
		
		System.out.println("\n Enter graph data in  Matrix Form: ");
		for(int i=1;i<=node;i++){
			for(int j=1;j<=node;j++){
				a[i][j]=ob.nextInt();
			}
		}

		
		for(int i=0;i<=node;i++){
			v[i]=new Vector();
		}

		for(int i=1;i<=node;i++){
			for(int j=1;j<=node;j++){
				if(a[i][j]==1){
					v[i].add(j);
				}
			}
		}

	
		System.out.print("Enter the starting vertex: ");
		int start=ob.nextInt();
		bfs(start);

	}
	static void bfs(int src) {
		Queue<Integer> q=new LinkedList();
		q.add(src);
		visited[src]=1;
		System.out.println("\nThe node which are reachable are :");
		Iterator it=q.iterator();
		while (it.hasNext()) {
			int curr=q.poll();
			for (int child : v[curr]) {
				if (visited[child]==0) {
					visited[child]=1;
					System.out.print(child+" ");
					q.add(child);
				}
			}
		}
		System.out.println();
	}
}