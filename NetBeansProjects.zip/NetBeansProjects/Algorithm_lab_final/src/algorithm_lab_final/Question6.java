package algorithm_lab_final;

import java.io.File;
import java.util.Scanner;

public class Question6{

	static int count=1;
	static int it=0;
	static int n;
	static int arr[][];
	static boolean hS=false;

	Question6(int n){
		this.n=n;
		arr=new int[n][n];
	}

	private void printBoard(){

		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				if(arr[i][j]==1){
					System.out.print("Q \t");
				}else{
					System.out.print("* \t");
				}
			}
			System.out.println();
		}
		System.out.printf("Number of iteration: %d\n",it);
		it=0;
	}

	public void solve(){

		solveColumn(0);

		if(!hS){
			System.out.println("No Solution");
		}
	}

	private void solveColumn(int col){

		if(col==n){
			hS=true;
			System.out.println("\nSolution #"+count+": ");
			printBoard();
			count++;
			return;
		}
		it+=1;
		for(int i=0;i<n;i++){
			if(isValidPlace(i,col)){
				arr[i][col]=1;
				solveColumn(col+1);
				arr[i][col]=0;
			}

		}
	}

	private boolean isValidPlace(int r,int c){

		for(int j=c;j>=0;j--){
			if(arr[r][j]==1){
				return false;
			}
		}
		for(int i=r, j=c;i>=0&&j>=0;i--,j--){
			if(arr[i][j]==1){
				return false;
			}
		}
		for(int i=r, j=c;i<n&&j>=0;i++,j--){
			if(arr[i][j]==1){
				return false;
			}
		}
		return true;
	}

	public static void main(String[] args){
		File f=new File("queen.txt");
		try{
			Scanner ob=new Scanner(f);
			int n=ob.nextInt();
			System.out.println(n);
			Question6 ob1=new Question6(n);
			ob1.solve();
		}catch(Exception e){
			System.out.println("Exception found");
		}

	}
}
