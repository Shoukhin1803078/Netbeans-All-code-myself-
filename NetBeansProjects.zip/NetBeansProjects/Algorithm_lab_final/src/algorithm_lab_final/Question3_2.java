
//package algorithm_lab_final;

import java.util.Scanner;

public class Question3_2{

	static long T;
	public static void Knapsack(int W[],int P[],int M,int n){
		int arr[][]=new int[n+1][M+1];

		for(int i=0;i<=n;i++){
			for(int j=0;j<=M;j++){
				arr[i][j]=0;
			}
		}

		for(int i=1;i<=n;i++){
			for(int j=0;j<=M;j++){
				arr[i][j]=arr[i-1][j];

				if((j>=W[i-1])&&(arr[i][j]<arr[i-1][j-W[i-1]]+P[i-1])){
					arr[i][j]=arr[i-1][j-W[i-1]]+P[i-1];
				}
			}
		}
		T=arr[n][M];

	}

	public static void main(String[] args){
		Scanner ob=new Scanner(System.in);
		System.out.println("Enter knapsack size : ");
		int M=ob.nextInt();
		
		int weight[]=new int[5];
		System.out.println("Enter 5 object weight :");
		for(int i=0;i<5;i++){weight[i]=ob.nextInt();}
		
		int profit[]=new int[5];
		System.out.println("Enter 5 object profit :");
		for(int i=0;i<5;i++){profit[i]=ob.nextInt();}
		
		int n=profit.length;
		Knapsack(weight,profit,M,n);
		System.out.println("Total profit is :"+T);
	}

}
